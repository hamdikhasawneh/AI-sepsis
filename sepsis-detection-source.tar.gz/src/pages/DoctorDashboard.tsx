import { useState } from 'react';
import { useLocation } from 'wouter';
import { motion, AnimatePresence } from 'framer-motion';
import {
  AreaChart, Area, LineChart, Line, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine, Cell
} from 'recharts';
import {
  Activity, Bell, LogOut, User, Search, AlertCircle, Clock,
  ChevronRight, Heart, Thermometer, Wind, Droplets, Brain, TriangleAlert, Info,
  TrendingUp, Microscope, FileText, Lightbulb, ShieldAlert
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { patients, vitalsHistory, alerts, shapData } from '@/lib/mock-data';
import { cn } from '@/lib/utils';

type Tab = 'overview' | 'vitals' | 'labs' | 'shap' | 'alerts';

function getRiskColor(level: string) {
  if (level === 'critical') return 'text-red-400 bg-red-950 border-red-800';
  if (level === 'high') return 'text-orange-400 bg-orange-950 border-orange-800';
  if (level === 'medium') return 'text-amber-400 bg-amber-950 border-amber-800';
  return 'text-emerald-400 bg-emerald-950 border-emerald-800';
}

function getRiskBar(level: string) {
  if (level === 'critical') return 'bg-red-500';
  if (level === 'high') return 'bg-orange-500';
  if (level === 'medium') return 'bg-amber-500';
  return 'bg-emerald-500';
}

function getRiskTextColor(level: string) {
  if (level === 'critical') return 'text-red-400';
  if (level === 'high') return 'text-orange-400';
  if (level === 'medium') return 'text-amber-400';
  return 'text-emerald-400';
}

const labResults = [
  { test: 'Serum Lactate', value: '3.8', unit: 'mmol/L', ref: '0.5–2.2', status: 'critical', time: '10 min ago' },
  { test: 'WBC Count', value: '18.2', unit: '10⁹/L', ref: '4.5–11.0', status: 'high', time: '2 hr ago' },
  { test: 'Creatinine', value: '2.1', unit: 'mg/dL', ref: '0.6–1.2', status: 'high', time: '2 hr ago' },
  { test: 'Platelet Count', value: '89', unit: '10⁹/L', ref: '150–400', status: 'low', time: '2 hr ago' },
  { test: 'Bilirubin Total', value: '1.8', unit: 'mg/dL', ref: '0.2–1.2', status: 'high', time: '4 hr ago' },
  { test: 'Procalcitonin', value: '12.4', unit: 'ng/mL', ref: '<0.1', status: 'critical', time: '4 hr ago' },
  { test: 'CRP', value: '224', unit: 'mg/L', ref: '<5.0', status: 'critical', time: '4 hr ago' },
  { test: 'Hemoglobin', value: '9.8', unit: 'g/dL', ref: '13.5–17.5', status: 'low', time: '2 hr ago' },
];

const hrData = vitalsHistory.map(v => ({ ...v, normal: 100 }));
const bpData = [
  { time: '00:00', sys: 122, dia: 80 }, { time: '04:00', sys: 118, dia: 76 },
  { time: '08:00', sys: 110, dia: 70 }, { time: '12:00', sys: 102, dia: 64 },
  { time: '16:00', sys: 95, dia: 58 }, { time: '20:00', sys: 90, dia: 55 },
  { time: '24:00', sys: 88, dia: 52 },
];

export function DoctorDashboard() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedPatient, setSelectedPatient] = useState(patients[2]);
  const [tab, setTab] = useState<Tab>('overview');
  const [searchQ, setSearchQ] = useState('');
  const unreadAlerts = alerts.filter(a => a.severity === 'critical' || a.severity === 'high').length;

  const myPatients = patients.filter(p => p.assignedDoctor === user?.id);

  const filteredPatients = myPatients.filter(p =>
    p.name.toLowerCase().includes(searchQ.toLowerCase()) || p.id.includes(searchQ)
  );

  const handleLogout = () => { logout(); setLocation('/'); };

  return (
    <div className="h-screen bg-slate-950 text-slate-200 flex flex-col overflow-hidden">
      {/* Top Navbar */}
      <header className="h-14 bg-slate-900 border-b border-slate-800 flex items-center px-4 gap-4 shrink-0">
        <div className="flex items-center gap-2 mr-4">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-blue-600 to-cyan-400 flex items-center justify-center">
            <Activity className="w-4 h-4 text-white" />
          </div>
          <span className="font-bold text-base hidden sm:block">Sepsis<span className="text-blue-400">AI</span></span>
        </div>
        <div className="flex-1" />
        <div className="flex items-center gap-3">
          <div className="relative">
            <Bell className="w-5 h-5 text-slate-400 hover:text-white cursor-pointer transition-colors" />
            {unreadAlerts > 0 && (
              <span className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">{unreadAlerts}</span>
            )}
          </div>
          <div className="flex items-center gap-2 pl-3 border-l border-slate-700">
            <div className="w-8 h-8 rounded-full bg-blue-900 border border-blue-700 flex items-center justify-center">
              <User className="w-4 h-4 text-blue-300" />
            </div>
            <div className="hidden sm:block">
              <p className="text-xs font-semibold text-slate-200 leading-tight">{user?.name}</p>
              <p className="text-[10px] text-slate-500">{user?.department}</p>
            </div>
          </div>
          <button onClick={handleLogout} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 text-xs transition-all">
            <LogOut className="w-3.5 h-3.5" /> Sign out
          </button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar — Patient List */}
        <aside className="w-72 bg-slate-900 border-r border-slate-800 flex flex-col shrink-0">
          <div className="p-3 border-b border-slate-800">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                value={searchQ} onChange={e => setSearchQ(e.target.value)}
                placeholder="Search patients..." 
                className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-3 py-2 text-xs focus:outline-none focus:border-blue-600 text-slate-300 placeholder:text-slate-600"
              />
            </div>
          </div>
          <div className="p-2 text-xs text-slate-500 font-semibold uppercase tracking-wider px-3 pt-3">
            Assigned Patients ({filteredPatients.length})
          </div>
          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {filteredPatients.map(p => (
              <button key={p.id} onClick={() => { setSelectedPatient(p); setTab('overview'); }}
                className={cn(
                  'w-full text-left p-3 rounded-lg border transition-all duration-150',
                  selectedPatient.id === p.id
                    ? 'bg-slate-800 border-blue-800/60'
                    : 'border-transparent hover:bg-slate-800/50 hover:border-slate-700'
                )}>
                <div className="flex justify-between items-center mb-1.5">
                  <span className="font-semibold text-sm text-slate-100 truncate mr-2">{p.name}</span>
                  <span className={cn('text-xs font-bold px-2 py-0.5 rounded border shrink-0', getRiskColor(p.riskLevel))}>
                    {p.score}%
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-500">{p.id} · {p.bed}</span>
                  {'alerts' in p && (
                    <span className="text-[10px] text-red-400 flex items-center gap-0.5">
                      <ShieldAlert className="w-3 h-3" />{(p as any).alerts}
                    </span>
                  )}
                </div>
                <div className="mt-2 h-1 bg-slate-800 rounded-full overflow-hidden">
                  <div className={cn('h-full rounded-full transition-all', getRiskBar(p.riskLevel))} style={{ width: `${p.score}%` }} />
                </div>
              </button>
            ))}
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto bg-slate-950">
          {/* Patient Header */}
          <div className="border-b border-slate-800 px-6 py-4 bg-slate-900/50 sticky top-0 z-10">
            <div className="flex items-start justify-between">
              <div>
                <h1 className="text-xl font-bold text-white">{selectedPatient.name}</h1>
                <p className="text-sm text-slate-400 mt-0.5">{selectedPatient.id} · {selectedPatient.bed} · Age 62 · Male · Admitted 24h ago</p>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-3">
                  <div>
                    <p className="text-xs text-slate-500 mb-1">Sepsis Risk Score</p>
                    <p className={cn('text-3xl font-bold', getRiskTextColor(selectedPatient.riskLevel))}>
                      {selectedPatient.score}<span className="text-lg">%</span>
                    </p>
                  </div>
                  <span className={cn('px-3 py-1.5 rounded-lg text-sm font-bold border uppercase', getRiskColor(selectedPatient.riskLevel))}>
                    {selectedPatient.riskLevel}
                  </span>
                </div>
              </div>
            </div>

            {selectedPatient.riskLevel === 'critical' && (
              <div className="mt-3 flex items-center gap-3 p-3 rounded-lg bg-red-950/60 border border-red-800">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <p className="text-sm text-red-300 flex-1">
                  <span className="font-bold">CRITICAL ALERT:</span> Risk score exceeded 80% threshold. Elevated lactate (3.8 mmol/L), tachycardia (118 bpm), hypotension (88/52). Immediate assessment required.
                </p>
                <button className="px-3 py-1 bg-red-500 text-white text-xs font-semibold rounded-lg hover:bg-red-600 shrink-0">Acknowledge</button>
              </div>
            )}

            {/* Tab Bar */}
            <div className="flex gap-1 mt-4">
              {([
                { id: 'overview', label: 'Overview', icon: Activity },
                { id: 'vitals', label: 'Vital Trends', icon: Heart },
                { id: 'labs', label: 'Lab Results', icon: Microscope },
                { id: 'shap', label: 'AI Reasoning', icon: Brain },
                { id: 'alerts', label: `Alerts (${unreadAlerts})`, icon: Bell },
              ] as { id: Tab; label: string; icon: any }[]).map(t => (
                <button key={t.id} onClick={() => setTab(t.id)}
                  className={cn(
                    'flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-all',
                    tab === t.id
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                  )}>
                  <t.icon className="w-3.5 h-3.5" />{t.label}
                </button>
              ))}
            </div>
          </div>

          <div className="p-6">
            <AnimatePresence mode="wait">
              <motion.div key={tab} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.15 }}>

                {tab === 'overview' && (
                  <div className="space-y-6">
                    {/* Vitals Grid */}
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                      {[
                        { label: 'Heart Rate', val: selectedPatient.hr, unit: 'bpm', icon: Heart, status: selectedPatient.hr > 100 ? 'critical' : 'normal', ref: '>100 = high' },
                        { label: 'Blood Pressure', val: selectedPatient.bp, unit: 'mmHg', icon: Activity, status: selectedPatient.bp.startsWith('88') ? 'critical' : 'normal', ref: 'MAP <65 = shock' },
                        { label: 'SpO2', val: selectedPatient.spo2, unit: '%', icon: Droplets, status: selectedPatient.spo2 < 95 ? 'high' : 'normal', ref: '<95 = low' },
                        { label: 'Resp. Rate', val: selectedPatient.rr, unit: '/min', icon: Wind, status: selectedPatient.rr > 20 ? 'high' : 'normal', ref: '>20 = tachypnea' },
                        { label: 'Temperature', val: selectedPatient.temp, unit: '°C', icon: Thermometer, status: selectedPatient.temp > 38 ? 'high' : 'normal', ref: '>38 = fever' },
                        { label: 'Lactate', val: selectedPatient.lactate, unit: 'mmol/L', icon: TrendingUp, status: selectedPatient.lactate > 2 ? 'critical' : 'normal', ref: '>2 = hypoperfusion' },
                      ].map((v, i) => (
                        <div key={i} className={cn('p-4 rounded-xl border flex flex-col gap-1',
                          v.status === 'critical' ? 'bg-red-950/40 border-red-800/50' :
                          v.status === 'high' ? 'bg-orange-950/30 border-orange-800/50' :
                          'bg-slate-900 border-slate-800')}>
                          <div className="flex justify-between items-center mb-1">
                            <span className="text-xs text-slate-500">{v.label}</span>
                            <v.icon className={cn('w-3.5 h-3.5', v.status !== 'normal' ? getRiskTextColor(v.status) : 'text-slate-600')} />
                          </div>
                          <span className={cn('text-2xl font-bold', v.status !== 'normal' ? getRiskTextColor(v.status) : 'text-slate-100')}>
                            {v.val}
                          </span>
                          <span className="text-[10px] text-slate-600">{v.unit} · {v.ref}</span>
                        </div>
                      ))}
                    </div>

                    {/* Risk Trajectory Chart */}
                    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="font-semibold text-slate-200 flex items-center gap-2">
                          <TrendingUp className="w-4 h-4 text-red-400" /> 24-Hour Sepsis Risk Trajectory
                        </h3>
                        <span className="text-xs text-slate-500">LSTM model predictions · updated every 15 min</span>
                      </div>
                      <div className="h-52">
                        <ResponsiveContainer width="100%" height="100%">
                          <AreaChart data={vitalsHistory} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                            <defs>
                              <linearGradient id="riskGrad" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3} />
                                <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                              </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                            <XAxis dataKey="time" stroke="#475569" fontSize={11} tickLine={false} axisLine={false} />
                            <YAxis stroke="#475569" fontSize={11} tickLine={false} axisLine={false} domain={[0, 100]} unit="%" />
                            <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#f8fafc', fontSize: 12 }} formatter={(v: any) => [`${v}%`, 'Sepsis Risk']} />
                            <ReferenceLine y={80} stroke="#ef4444" strokeDasharray="4 2" label={{ value: 'Critical (80%)', fill: '#f87171', fontSize: 10, position: 'insideTopLeft' }} />
                            <ReferenceLine y={50} stroke="#f97316" strokeDasharray="4 2" label={{ value: 'High (50%)', fill: '#fb923c', fontSize: 10, position: 'insideTopLeft' }} />
                            <Area type="monotone" dataKey="risk" stroke="#ef4444" strokeWidth={2.5} fillOpacity={1} fill="url(#riskGrad)" dot={{ fill: '#ef4444', r: 3 }} />
                          </AreaChart>
                        </ResponsiveContainer>
                      </div>
                    </div>

                    {/* Clinical Notes */}
                    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
                      <h3 className="font-semibold text-slate-200 flex items-center gap-2 mb-3">
                        <FileText className="w-4 h-4 text-slate-400" /> Clinical Context (MIMIC-IV Extract)
                      </h3>
                      <p className="text-sm text-slate-400 font-mono leading-relaxed bg-slate-950 p-4 rounded-lg border border-slate-800">
                        62 yo M presenting from ED with altered mental status, fever (38.9°C), and productive cough. 
                        Hypotensive on arrival responding poorly to 1L crystalloid bolus. Initiated on empiric broad-spectrum antibiotics (Vancomycin + Piperacillin-tazobactam). 
                        Transferred to ICU for hemodynamic monitoring. Primary concern: developing septic shock secondary to severe community-acquired pneumonia with suspected bacteremia (blood cultures pending).
                        SOFA score: 9. Norepinephrine started at 0.05 mcg/kg/min.
                      </p>
                    </div>
                  </div>
                )}

                {tab === 'vitals' && (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      {/* Heart Rate */}
                      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
                        <h3 className="font-semibold text-slate-200 flex items-center gap-2 mb-4">
                          <Heart className="w-4 h-4 text-red-400" /> Heart Rate (24h)
                        </h3>
                        <div className="h-52">
                          <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={hrData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                              <XAxis dataKey="time" stroke="#475569" fontSize={11} tickLine={false} axisLine={false} />
                              <YAxis stroke="#475569" fontSize={11} tickLine={false} axisLine={false} unit=" bpm" />
                              <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', fontSize: 12 }} />
                              <ReferenceLine y={100} stroke="#f97316" strokeDasharray="4 2" label={{ value: 'Tachycardia (100)', fill: '#fb923c', fontSize: 10 }} />
                              <Line type="monotone" dataKey="hr" stroke="#ef4444" strokeWidth={2.5} dot={{ fill: '#ef4444', r: 3 }} name="Heart Rate" />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      </div>

                      {/* Blood Pressure */}
                      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
                        <h3 className="font-semibold text-slate-200 flex items-center gap-2 mb-4">
                          <Activity className="w-4 h-4 text-blue-400" /> Blood Pressure (24h)
                        </h3>
                        <div className="h-52">
                          <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={bpData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                              <XAxis dataKey="time" stroke="#475569" fontSize={11} tickLine={false} axisLine={false} />
                              <YAxis stroke="#475569" fontSize={11} tickLine={false} axisLine={false} unit=" mmHg" />
                              <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', fontSize: 12 }} />
                              <ReferenceLine y={90} stroke="#ef4444" strokeDasharray="4 2" label={{ value: 'Hypotension threshold', fill: '#f87171', fontSize: 10 }} />
                              <Line type="monotone" dataKey="sys" stroke="#60a5fa" strokeWidth={2.5} dot={{ fill: '#60a5fa', r: 3 }} name="Systolic" />
                              <Line type="monotone" dataKey="dia" stroke="#818cf8" strokeWidth={2} dot={false} name="Diastolic" strokeDasharray="4 2" />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      </div>

                      {/* Respiratory Rate + Temp */}
                      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
                        <h3 className="font-semibold text-slate-200 flex items-center gap-2 mb-4">
                          <Wind className="w-4 h-4 text-cyan-400" /> Respiratory Rate & Temperature (24h)
                        </h3>
                        <div className="h-52">
                          <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={vitalsHistory} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                              <XAxis dataKey="time" stroke="#475569" fontSize={11} tickLine={false} axisLine={false} />
                              <YAxis yAxisId="rr" stroke="#475569" fontSize={11} tickLine={false} axisLine={false} unit="/min" />
                              <YAxis yAxisId="temp" orientation="right" stroke="#475569" fontSize={11} tickLine={false} axisLine={false} unit="°C" domain={[36, 40]} />
                              <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', fontSize: 12 }} />
                              <ReferenceLine yAxisId="rr" y={20} stroke="#f97316" strokeDasharray="3 2" />
                              <Line yAxisId="rr" type="monotone" dataKey="rr" stroke="#22d3ee" strokeWidth={2.5} dot={{ fill: '#22d3ee', r: 3 }} name="Resp. Rate" />
                              <Line yAxisId="temp" type="monotone" dataKey="temp" stroke="#f59e0b" strokeWidth={2} dot={false} name="Temperature" strokeDasharray="5 2" />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      </div>

                      {/* Risk score area chart */}
                      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
                        <h3 className="font-semibold text-slate-200 flex items-center gap-2 mb-4">
                          <Brain className="w-4 h-4 text-violet-400" /> Risk Score Progression (24h)
                        </h3>
                        <div className="h-52">
                          <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={vitalsHistory} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                              <defs>
                                <linearGradient id="rG2" x1="0" y1="0" x2="0" y2="1">
                                  <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                                  <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                                </linearGradient>
                              </defs>
                              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                              <XAxis dataKey="time" stroke="#475569" fontSize={11} tickLine={false} axisLine={false} />
                              <YAxis stroke="#475569" fontSize={11} tickLine={false} axisLine={false} domain={[0, 100]} unit="%" />
                              <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', fontSize: 12 }} formatter={(v: any) => [`${v}%`, 'Risk Score']} />
                              <Area type="monotone" dataKey="risk" stroke="#8b5cf6" strokeWidth={2.5} fillOpacity={1} fill="url(#rG2)" dot={{ fill: '#8b5cf6', r: 3 }} />
                            </AreaChart>
                          </ResponsiveContainer>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {tab === 'labs' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h2 className="text-lg font-bold text-white">Laboratory Results — {selectedPatient.name}</h2>
                      <span className="text-xs text-slate-500">Latest available results</span>
                    </div>
                    <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="text-xs font-semibold text-slate-500 uppercase bg-slate-950 border-b border-slate-800">
                            <th className="px-5 py-3 text-left">Test</th>
                            <th className="px-5 py-3 text-left">Value</th>
                            <th className="px-5 py-3 text-left">Units</th>
                            <th className="px-5 py-3 text-left">Reference Range</th>
                            <th className="px-5 py-3 text-left">Status</th>
                            <th className="px-5 py-3 text-left">Collected</th>
                          </tr>
                        </thead>
                        <tbody>
                          {labResults.map((lab, i) => (
                            <tr key={i} className={cn('border-b border-slate-800 last:border-0 transition-colors',
                              lab.status === 'critical' ? 'bg-red-950/20' :
                              lab.status === 'high' || lab.status === 'low' ? 'bg-orange-950/10' : '')}>
                              <td className="px-5 py-3 font-medium text-slate-200">{lab.test}</td>
                              <td className={cn('px-5 py-3 font-bold text-base',
                                lab.status === 'critical' ? 'text-red-400' :
                                lab.status === 'high' || lab.status === 'low' ? 'text-orange-400' : 'text-slate-200')}>
                                {lab.value}
                              </td>
                              <td className="px-5 py-3 text-slate-500 text-xs">{lab.unit}</td>
                              <td className="px-5 py-3 text-slate-500 text-xs font-mono">{lab.ref}</td>
                              <td className="px-5 py-3">
                                <span className={cn('text-xs font-bold px-2 py-0.5 rounded uppercase',
                                  lab.status === 'critical' ? 'bg-red-950 text-red-400 border border-red-800' :
                                  lab.status === 'high' ? 'bg-orange-950 text-orange-400 border border-orange-800' :
                                  lab.status === 'low' ? 'bg-blue-950 text-blue-400 border border-blue-800' :
                                  'bg-emerald-950 text-emerald-400 border border-emerald-800')}>
                                  {lab.status}
                                </span>
                              </td>
                              <td className="px-5 py-3 text-slate-500 text-xs">{lab.time}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>

                    {/* Organ function summary */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                      {[
                        { organ: 'Renal', indicator: 'Creatinine 2.1', status: 'Impaired', color: 'border-orange-800 bg-orange-950/30 text-orange-400' },
                        { organ: 'Hepatic', indicator: 'Bilirubin 1.8', status: 'Borderline', color: 'border-amber-800 bg-amber-950/30 text-amber-400' },
                        { organ: 'Hematologic', indicator: 'PLT 89 (↓)', status: 'Abnormal', color: 'border-red-800 bg-red-950/30 text-red-400' },
                        { organ: 'Inflammatory', indicator: 'PCT 12.4, CRP 224', status: 'Severe', color: 'border-red-800 bg-red-950/30 text-red-400' },
                      ].map((o, i) => (
                        <div key={i} className={cn('p-4 rounded-xl border', o.color)}>
                          <p className="text-xs text-slate-500 mb-1">{o.organ} Function</p>
                          <p className="text-sm font-semibold text-slate-200">{o.indicator}</p>
                          <p className={cn('text-xs font-bold mt-1', o.color.split(' ')[2])}>{o.status}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {tab === 'shap' && <SHAPView patient={selectedPatient} />}

                {tab === 'alerts' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-3 gap-4 mb-2">
                      {[
                        { label: 'Critical', count: 2, color: 'text-red-400 bg-red-950/40 border-red-800' },
                        { label: 'High Priority', count: 2, color: 'text-orange-400 bg-orange-950/40 border-orange-800' },
                        { label: 'All Active', count: alerts.length, color: 'text-slate-200 bg-slate-900 border-slate-700' },
                      ].map((s, i) => (
                        <div key={i} className={cn('p-4 rounded-xl border flex justify-between items-center', s.color)}>
                          <div>
                            <p className="text-xs text-slate-500">{s.label}</p>
                            <p className={cn('text-2xl font-bold', s.color.split(' ')[0])}>{s.count}</p>
                          </div>
                          <Bell className={cn('w-6 h-6 opacity-40', s.color.split(' ')[0])} />
                        </div>
                      ))}
                    </div>
                    <div className="space-y-2">
                      {alerts.map(alert => (
                        <div key={alert.id} className={cn(
                          'p-4 rounded-xl border flex items-start justify-between gap-4',
                          alert.severity === 'critical' ? 'bg-red-950/30 border-red-800/50' :
                          alert.severity === 'high' ? 'bg-orange-950/20 border-orange-800/40' :
                          alert.severity === 'medium' ? 'bg-amber-950/10 border-amber-800/30' :
                          'bg-slate-900 border-slate-800')}>
                          <div className="flex gap-3 flex-1">
                            <div className="mt-0.5 shrink-0">
                              {alert.severity === 'critical' && <AlertCircle className="w-5 h-5 text-red-400" />}
                              {alert.severity === 'high' && <TriangleAlert className="w-5 h-5 text-orange-400" />}
                              {alert.severity === 'medium' && <Info className="w-5 h-5 text-amber-400" />}
                              {alert.severity === 'low' && <Bell className="w-5 h-5 text-slate-500" />}
                            </div>
                            <div>
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-bold text-slate-200 text-sm">{alert.patientId}</span>
                                <span className="text-xs text-slate-500 flex items-center gap-1"><Clock className="w-3 h-3" />{alert.time}</span>
                              </div>
                              <p className={cn('text-sm', alert.severity === 'critical' ? 'text-red-300 font-medium' : 'text-slate-300')}>{alert.message}</p>
                            </div>
                          </div>
                          {(alert.severity === 'critical' || alert.severity === 'high') && (
                            <button className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-medium rounded-lg border border-slate-600 transition-colors shrink-0">
                              Review <ChevronRight className="w-3 h-3 inline" />
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

              </motion.div>
            </AnimatePresence>
          </div>
        </main>
      </div>
    </div>
  );
}

function SHAPView({ patient }: { patient: any }) {
  const sortedShap = [...shapData].sort((a, b) => Math.abs(b.impact) - Math.abs(a.impact));
  const maxImpact = Math.max(...shapData.map(d => Math.abs(d.impact)));

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Natural Language Explanation */}
        <div className="lg:col-span-2 bg-slate-900 border border-blue-900/60 rounded-xl p-5">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-9 h-9 rounded-lg bg-blue-900/60 border border-blue-700 flex items-center justify-center shrink-0">
              <Lightbulb className="w-5 h-5 text-blue-300" />
            </div>
            <div>
              <h3 className="font-bold text-slate-100 text-base">AI Clinical Reasoning</h3>
              <p className="text-xs text-blue-400 mt-0.5">Generated by SHAP explainability module · LSTM model</p>
            </div>
          </div>
          <div className="space-y-3 text-sm leading-relaxed text-slate-300">
            <p>
              The model predicts a <span className="font-bold text-red-400">CRITICAL sepsis risk of {patient.score}%</span> for {patient.name}. 
              This prediction is primarily driven by the following clinical findings:
            </p>
            <ul className="space-y-2 ml-4">
              <li className="flex items-start gap-2">
                <span className="mt-1.5 w-2 h-2 rounded-full bg-red-500 shrink-0" />
                <span><span className="text-red-400 font-semibold">Serum Lactate (3.8 mmol/L):</span> Significantly above the normal range (0.5–2.2), indicating tissue hypoperfusion and impaired cellular oxygen utilization — the strongest positive contributor to this prediction.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="mt-1.5 w-2 h-2 rounded-full bg-orange-500 shrink-0" />
                <span><span className="text-orange-400 font-semibold">Heart Rate (118 bpm):</span> Sustained tachycardia above 100 bpm for over 6 hours. The temporal trend (rising from 85 to 118 over 24h) significantly amplifies the model's concern for sepsis-driven compensatory response.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="mt-1.5 w-2 h-2 rounded-full bg-blue-500 shrink-0" />
                <span><span className="text-blue-400 font-semibold">Mean Arterial Pressure (≈64 mmHg):</span> Falling MAP, now at the septic shock threshold of 65 mmHg. This is a strong <em>negative</em> contributor — lower MAP increases sepsis risk significantly.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="mt-1.5 w-2 h-2 rounded-full bg-cyan-500 shrink-0" />
                <span><span className="text-cyan-400 font-semibold">Respiratory Rate (24/min):</span> Progressive tachypnea consistent with compensatory hyperventilation in the setting of metabolic acidosis from tissue hypoperfusion.</span>
              </li>
            </ul>
            <div className="mt-4 p-3 rounded-lg bg-blue-950/50 border border-blue-800/50 text-xs text-blue-300">
              <strong>Temporal Context:</strong> The LSTM model detected a consistent upward trajectory across all key indicators over the past 24 hours. 
              This multi-variable deterioration pattern — not any single threshold breach — is what elevates the risk score to CRITICAL. 
              The model was trained on MIMIC-IV ICU data with standardized Sepsis-3 labeling criteria.
            </div>
          </div>
        </div>

        {/* Confidence + Model Info */}
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <h4 className="text-sm font-semibold text-slate-300 mb-4">Prediction Confidence</h4>
            <div className="text-center mb-4">
              <div className="text-4xl font-bold text-red-400">{patient.score}%</div>
              <div className="text-xs text-slate-500 mt-1">Sepsis Risk Score</div>
            </div>
            {[
              { label: 'Model Confidence', val: 94, color: 'bg-blue-500' },
              { label: 'Sepsis Risk', val: patient.score, color: 'bg-red-500' },
              { label: 'Organ Failure Risk', val: 71, color: 'bg-orange-500' },
            ].map((m, i) => (
              <div key={i} className="mb-3">
                <div className="flex justify-between text-xs text-slate-400 mb-1">
                  <span>{m.label}</span><span className="font-semibold">{m.val}%</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div className={cn('h-full rounded-full', m.color)} style={{ width: `${m.val}%` }} />
                </div>
              </div>
            ))}
          </div>
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 text-xs space-y-2 text-slate-400">
            <p className="font-semibold text-slate-300 mb-2">Model Info</p>
            <div className="flex justify-between"><span>Architecture</span><span className="text-blue-400">LSTM (48-layer)</span></div>
            <div className="flex justify-between"><span>Trained on</span><span className="text-slate-300">MIMIC-IV</span></div>
            <div className="flex justify-between"><span>AUROC</span><span className="text-emerald-400">0.89</span></div>
            <div className="flex justify-between"><span>Labeling</span><span className="text-slate-300">Sepsis-3</span></div>
            <div className="flex justify-between"><span>Updated</span><span className="text-slate-300">2 min ago</span></div>
          </div>
        </div>
      </div>

      {/* SHAP Chart */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
        <h3 className="font-semibold text-slate-200 mb-1">SHAP Feature Importance (Top 10)</h3>
        <p className="text-xs text-slate-500 mb-5">
          Red bars = features increasing risk · Blue bars = features decreasing risk · Bar length = magnitude of contribution
        </p>
        <div className="space-y-3">
          {sortedShap.map((d, i) => {
            const pct = (Math.abs(d.impact) / maxImpact) * 100;
            const isPos = d.direction === 'positive';
            return (
              <div key={i} className="flex items-center gap-3">
                <span className="text-xs text-slate-400 w-36 shrink-0 text-right">{d.feature}</span>
                <div className="flex-1 flex items-center gap-1">
                  {!isPos && (
                    <div className="flex-1 flex justify-end">
                      <div className="h-6 rounded-l-full bg-blue-600/80 flex items-center justify-end pr-2 transition-all"
                        style={{ width: `${pct}%` }}>
                        <span className="text-[10px] text-white font-bold">{d.impact.toFixed(2)}</span>
                      </div>
                    </div>
                  )}
                  <div className="w-px h-6 bg-slate-600" />
                  {isPos && (
                    <div className="flex-1">
                      <div className="h-6 rounded-r-full bg-red-500/80 flex items-center pl-2 transition-all"
                        style={{ width: `${pct}%` }}>
                        <span className="text-[10px] text-white font-bold">+{d.impact.toFixed(2)}</span>
                      </div>
                    </div>
                  )}
                  {!isPos && <div className="flex-1" />}
                </div>
              </div>
            );
          })}
        </div>
        <div className="flex justify-center gap-6 mt-4 text-xs text-slate-500">
          <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded bg-blue-600" /> Decreases Risk (negative SHAP)</div>
          <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded bg-red-500" /> Increases Risk (positive SHAP)</div>
        </div>
      </div>
    </div>
  );
}
