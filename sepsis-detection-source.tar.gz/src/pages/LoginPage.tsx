import { useState } from 'react';
import { useLocation } from 'wouter';
import { motion, AnimatePresence } from 'framer-motion';
import { Activity, Eye, EyeOff, Stethoscope, UserCog, AlertCircle, ShieldCheck, Lock, ChevronRight, ArrowLeft } from 'lucide-react';
import { useAuth, type UserRole, DEMO_CREDENTIALS } from '@/context/AuthContext';
import { cn } from '@/lib/utils';

export function LoginPage() {
  const [, setLocation] = useLocation();
  const { login } = useAuth();
  const [role, setRole] = useState<UserRole>('doctor');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const fillDemo = () => {
    setEmail(DEMO_CREDENTIALS[role].email);
    setPassword('demo1234');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    const result = await login(email, password, role);
    setLoading(false);
    if (result.success) {
      setLocation(role === 'doctor' ? '/dashboard/doctor' : '/dashboard/nurse');
    } else {
      setError(result.error || 'Login failed');
    }
  };

  return (
    <div className="min-h-screen flex bg-slate-50">
      {/* Left Panel — Branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-blue-950 via-blue-900 to-slate-900 flex-col justify-between p-12 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-[-20%] right-[-10%] w-[600px] h-[600px] rounded-full bg-blue-500/10 blur-[120px]" />
          <div className="absolute bottom-[-10%] left-[-10%] w-[400px] h-[400px] rounded-full bg-teal-500/10 blur-[100px]" />
          <div className="absolute inset-0 opacity-5 bg-[linear-gradient(rgba(255,255,255,.05)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,.05)_1px,transparent_1px)] bg-[size:40px_40px]" />
        </div>
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-16">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-blue-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-blue-500/30">
              <Activity className="w-7 h-7 text-white" />
            </div>
            <span className="font-bold text-2xl text-white tracking-tight">Sepsis<span className="text-blue-400">AI</span></span>
          </div>
          <h1 className="text-4xl font-bold text-white leading-tight mb-6">
            AI-Assisted ICU<br />
            <span className="text-blue-400">Sepsis Detection</span><br />
            System
          </h1>
          <p className="text-blue-200 text-lg leading-relaxed max-w-sm">
            Real-time sepsis risk prediction, continuous vital monitoring, and explainable AI for safer, faster clinical decision-making.
          </p>
        </div>

        <div className="relative z-10 space-y-4">
          {[
            { icon: ShieldCheck, label: 'Real-Time Risk Prediction', desc: 'Updated every 15 minutes' },
            { icon: Activity, label: 'Vital Trend Monitoring', desc: 'Heart rate, BP, SpO2, Lactate' },
            { icon: Lock, label: 'SHAP Explainability', desc: 'Transparent AI reasoning' },
          ].map((item, i) => (
            <motion.div key={i} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.1 + 0.3 }}
              className="flex items-center gap-4 p-4 rounded-xl bg-white/5 border border-white/10">
              <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center shrink-0">
                <item.icon className="w-5 h-5 text-blue-300" />
              </div>
              <div>
                <p className="text-white font-semibold text-sm">{item.label}</p>
                <p className="text-blue-300 text-xs">{item.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Right Panel — Login Form */}
      <div className="flex-1 flex flex-col justify-center items-center p-6 sm:p-12">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="w-full max-w-md">

          <button onClick={() => setLocation('/')} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-10 transition-colors group">
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
            Back to homepage
          </button>

          {/* Logo for mobile */}
          <div className="flex items-center gap-2 mb-8 lg:hidden">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-cyan-400 flex items-center justify-center">
              <Activity className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-xl">Sepsis<span className="text-blue-600">AI</span></span>
          </div>

          <h2 className="text-3xl font-bold mb-2">Welcome back</h2>
          <p className="text-muted-foreground mb-8">Sign in to access your ICU dashboard</p>

          {/* Role Selector */}
          <div className="mb-6">
            <label className="text-sm font-semibold text-foreground mb-2 block">Select your role</label>
            <div className="grid grid-cols-2 gap-3">
              {([
                { id: 'doctor', label: 'Physician', icon: Stethoscope, desc: 'Full patient analytics & SHAP' },
                { id: 'nurse', label: 'Nurse', icon: UserCog, desc: 'Monitoring & lab uploads' },
              ] as const).map((r) => (
                <button key={r.id} type="button" onClick={() => { setRole(r.id); setEmail(''); setPassword(''); setError(''); }}
                  className={cn(
                    'p-4 rounded-xl border-2 text-left transition-all duration-200',
                    role === r.id
                      ? 'border-blue-500 bg-blue-50 shadow-sm shadow-blue-100'
                      : 'border-border bg-white hover:border-blue-200 hover:bg-slate-50'
                  )}>
                  <r.icon className={cn('w-5 h-5 mb-2', role === r.id ? 'text-blue-600' : 'text-slate-400')} />
                  <p className={cn('font-bold text-sm', role === r.id ? 'text-blue-700' : 'text-foreground')}>{r.label}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{r.desc}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Demo credentials hint */}
          <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200 mb-6">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
              <span className="text-xs text-amber-700">Demo mode — any email with password <code className="font-mono font-bold">demo1234</code></span>
            </div>
            <button type="button" onClick={fillDemo} className="text-xs font-semibold text-amber-700 hover:text-amber-900 whitespace-nowrap ml-2 hover:underline">
              Fill demo →
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-sm font-semibold text-foreground mb-1.5 block">Email address</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={DEMO_CREDENTIALS[role].email}
                required
                className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all text-sm"
              />
            </div>
            <div>
              <label className="text-sm font-semibold text-foreground mb-1.5 block">Password</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="w-full px-4 py-3 pr-12 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all text-sm"
                />
                <button type="button" onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 transition-colors">
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <AnimatePresence>
              {error && (
                <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                  className="flex items-center gap-2 p-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-700">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  {error}
                </motion.div>
              )}
            </AnimatePresence>

            <button type="submit" disabled={loading}
              className={cn(
                'w-full py-3.5 rounded-xl font-semibold text-white text-sm flex items-center justify-center gap-2 transition-all duration-300',
                loading
                  ? 'bg-blue-400 cursor-not-allowed'
                  : 'bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 shadow-lg shadow-blue-500/25 hover:-translate-y-0.5 hover:shadow-xl hover:shadow-blue-500/30'
              )}>
              {loading ? (
                <>
                  <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                  Authenticating...
                </>
              ) : (
                <>
                  Sign in as {role === 'doctor' ? 'Physician' : 'Nurse'}
                  <ChevronRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          <p className="text-center text-xs text-muted-foreground mt-8">
            This system is for authorized hospital personnel only.<br />
            Unauthorized access is strictly prohibited.
          </p>
        </motion.div>
      </div>
    </div>
  );
}
