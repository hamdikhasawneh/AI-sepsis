import { Navbar } from '@/components/layout/Navbar';
import { Hero } from '@/components/sections/Hero';
import { Problem } from '@/components/sections/Problem';
import { Overview } from '@/components/sections/Overview';
import { Features } from '@/components/sections/Features';
import { DashboardDemo } from '@/components/sections/DashboardDemo';
import { AIModels } from '@/components/sections/AIModels';
import { Methodology } from '@/components/sections/Methodology';
import { Stakeholders } from '@/components/sections/Stakeholders';
import { WhyDifferent } from '@/components/sections/WhyDifferent';
import { Deliverables } from '@/components/sections/Deliverables';
import { Team } from '@/components/sections/Team';
import { FutureWork } from '@/components/sections/FutureWork';
import { Footer } from '@/components/layout/Footer';

export function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <Hero />
        <Problem />
        <Overview />
        <Features />
        <DashboardDemo />
        <AIModels />
        <Methodology />
        <Stakeholders />
        <WhyDifferent />
        <Deliverables />
        <Team />
        <FutureWork />
      </main>
      <Footer />
    </div>
  );
}
