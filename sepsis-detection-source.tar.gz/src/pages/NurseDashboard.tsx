import { useState } from 'react';
import { useLocation } from 'wouter';
import { motion, AnimatePresence } from 'framer-motion';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts';
import {
  Activity, Bell, LogOut, User, AlertCircle, Clock,
  Syringe, Upload, Check, TriangleAlert, Info, Heart,
  Thermometer, Wind, Droplets, TrendingUp, RefreshCw,
  FileText, X, FileUp, ClipboardList
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { patients, alerts, vitalsHistory } from '@/lib/mock-data';
import { cn } from '@/lib/utils';

function getRiskColor(level: string) {
  if (level === 'critical') return 'text-red-400 bg-red-950/60 border-red-800';
  if (level === 'high') return 'text-orange-400 bg-orange-950/60 border-orange-800';
  if (level === 'medium') return 'text-amber-400 bg-amber-950/60 border-amber-800';
  return 'text-emerald-400 bg-emerald-950/60 border-emerald-800';
}
function getRiskBar(level: string) {
  if (level === 'critical') return 'bg-red-500';
  if (level === 'high') return 'bg-orange-500';
  if (level === 'medium') return 'bg-amber-500';
  return 'bg-emerald-500';
}

const sortedPatients = [...patients].sort((a, b) => b.score - a.score);
const urgentPatients = patients.filter(p => p.riskLevel === 'critical' || p.riskLevel === 'high');

export function NurseDashboard() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedPatient, setSelectedPatient] = useState(patients[2]);
  const [tab, setTab] = useState<'monitor' | 'upload' | 'alerts'>('monitor');
  const [labEntryMode, setLabEntryMode] = useState<'manual' | 'pdf'>('manual');
  const [labForm, setLabForm] = useState({ patient: 'ICU-003', lactate: '', wbc: '', creatinine: '', platelets: '', hemoglobin: '', sodium: '' });
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [pdfDragging, setPdfDragging] = useState(false);
  const [pdfUploaded, setPdfUploaded] = useState(false);
  const [pdfUploading, setPdfUploading] = useState(false);
  const unread = alerts.filter(a => a.severity === 'critical' || a.severity === 'high').length;

  const handleLogout = () => { logout(); setLocation('/'); };

  const handleSubmitLab = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    await new Promise(r => setTimeout(r, 1200));
    setSubmitting(false);
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 4000);
  };

  const handlePdfDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setPdfDragging(false);
    const file = e.dataTransfer.files[0];
    if (file && file.type === 'application/pdf') setPdfFile(file);
  };

  const handlePdfChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type === 'application/pdf') setPdfFile(file);
  };

  const handlePdfSubmit = async () => {
    if (!pdfFile) return;
    setPdfUploading(true);
    await new Promise(r => setTimeout(r, 1800));
    setPdfUploading(false);
    setPdfUploaded(true);
    setTimeout(() => { setPdfUploaded(false); setPdfFile(null); }, 5000);
  };

  return (
    <div className="h-screen bg-slate-950 text-slate-200 flex flex-col overflow-hidden">
      {/* Navbar */}
      <header className="h-14 bg-slate-900 border-b border-slate-800 flex items-center px-4 gap-4 shrink-0">
        <div className="flex items-center gap-2 mr-4">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-blue-600 to-cyan-400 flex items-center justify-center">
            <Activity className="w-4 h-4 text-white" />
          </div>
          <span className="font-bold text-base hidden sm:block">Sepsis<span className="text-blue-400">AI</span></span>
          <span className="text-xs text-slate-500 ml-1 hidden sm:block">· Nursing View</span>
        </div>
        <div className="flex-1" />
        <div className="flex items-center gap-3">
          <div className="relative">
            <Bell className="w-5 h-5 text-slate-400 hover:text-white cursor-pointer transition-colors" />
            {unread > 0 && (
              <span className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">{unread}</span>
            )}
          </div>
          <div className="flex items-center gap-2 pl-3 border-l border-slate-700">
            <div className="w-8 h-8 rounded-full bg-teal-900 border border-teal-700 flex items-center justify-center">
              <User className="w-4 h-4 text-teal-300" />
            </div>
            <div className="hidden sm:block">
              <p className="text-xs font-semibold text-slate-200 leading-tight">{user?.name}</p>
              <p className="text-[10px] text-slate-500">{user?.department}</p>
            </div>
          </div>
          <button onClick={handleLogout} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 text-xs transition-all">
            <LogOut className="w-3.5 h-3.5" /> Sign out
          </button>
        </div>
      </header>

      {/* Main */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-5 space-y-5">

          {/* Summary Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: 'Total Patients', val: patients.length, icon: User, color: 'text-slate-200' },
              { label: 'Critical Alerts', val: patients.filter(p => p.riskLevel === 'critical').length, icon: AlertCircle, color: 'text-red-400' },
              { label: 'High Risk', val: patients.filter(p => p.riskLevel === 'high').length, icon: TriangleAlert, color: 'text-orange-400' },
              { label: 'Pending Labs', val: 3, icon: Syringe, color: 'text-blue-400' },
            ].map((s, i) => (
              <div key={i} className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-500 mb-1">{s.label}</p>
                  <p className={cn('text-2xl font-bold', s.color)}>{s.val}</p>
                </div>
                <s.icon className={cn('w-6 h-6 opacity-50', s.color)} />
              </div>
            ))}
          </div>

          {/* Tab Bar */}
          <div className="flex gap-1 bg-slate-900 border border-slate-800 rounded-xl p-1 w-fit">
            {[
              { id: 'monitor', label: 'Unit Monitor', icon: Activity },
              { id: 'upload', label: 'Enter Lab Results', icon: Upload },
              { id: 'alerts', label: `Alerts (${unread})`, icon: Bell },
            ].map(t => (
              <button key={t.id} onClick={() => setTab(t.id as any)}
                className={cn(
                  'flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold transition-all',
                  tab === t.id ? 'bg-blue-600 text-white shadow' : 'text-slate-400 hover:text-white hover:bg-slate-800'
                )}>
                <t.icon className="w-3.5 h-3.5" />{t.label}
              </button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            <motion.div key={tab} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.15 }}>

              {tab === 'monitor' && (
                <div className="space-y-5">
                  {/* Urgent patients banner */}
                  {urgentPatients.length > 0 && (
                    <div className="p-4 rounded-xl bg-red-950/30 border border-red-800/50 flex items-center gap-3">
                      <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
                      <p className="text-sm text-red-300">
                        <span className="font-bold">{urgentPatients.length} patient(s) require urgent attention:</span>{' '}
                        {urgentPatients.map(p => `${p.name} (${p.riskLevel.toUpperCase()})`).join(', ')}
                      </p>
                    </div>
                  )}

                  {/* Patient Cards Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {sortedPatients.map(p => (
                      <motion.div key={p.id} whileHover={{ scale: 1.01 }} transition={{ duration: 0.1 }}
                        onClick={() => setSelectedPatient(p)}
                        className={cn(
                          'bg-slate-900 border rounded-xl p-4 cursor-pointer transition-all relative overflow-hidden',
                          selectedPatient.id === p.id ? 'border-blue-700 shadow-lg shadow-blue-900/20' : 'border-slate-800 hover:border-slate-700'
                        )}>
                        <div className={cn('absolute top-0 left-0 w-1 h-full', getRiskBar(p.riskLevel))} />
                        <div className="pl-2">
                          <div className="flex justify-between items-start mb-3">
                            <div>
                              <h4 className="font-bold text-slate-100">{p.name}</h4>
                              <p className="text-xs text-slate-500">{p.id} · {p.bed}</p>
                            </div>
                            <span className={cn('text-xs font-bold px-2 py-1 rounded border', getRiskColor(p.riskLevel))}>
                              {p.riskLevel.toUpperCase()}
                            </span>
                          </div>
                          <div className="mb-3">
                            <div className="flex justify-between text-xs text-slate-500 mb-1">
                              <span>Sepsis Risk Score</span><span className="font-semibold text-slate-300">{p.score}%</span>
                            </div>
                            <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                              <div className={cn('h-full rounded-full transition-all', getRiskBar(p.riskLevel))} style={{ width: `${p.score}%` }} />
                            </div>
                          </div>
                          <div className="grid grid-cols-3 gap-2 text-xs">
                            <div className={cn('text-center p-1.5 rounded', p.hr > 100 ? 'bg-orange-950/60 text-orange-400' : 'bg-slate-800 text-slate-300')}>
                              <Heart className="w-3 h-3 mx-auto mb-0.5" />{p.hr}
                            </div>
                            <div className={cn('text-center p-1.5 rounded', p.spo2 < 95 ? 'bg-orange-950/60 text-orange-400' : 'bg-slate-800 text-slate-300')}>
                              <Droplets className="w-3 h-3 mx-auto mb-0.5" />{p.spo2}%
                            </div>
                            <div className={cn('text-center p-1.5 rounded', p.temp > 38 ? 'bg-orange-950/60 text-orange-400' : 'bg-slate-800 text-slate-300')}>
                              <Thermometer className="w-3 h-3 mx-auto mb-0.5" />{p.temp}°
                            </div>
                          </div>
                          <div className="flex justify-between items-center mt-3 text-xs text-slate-500">
                            <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{p.lastUpdate}</span>
                            {'alerts' in p && <span className="text-red-400 flex items-center gap-1"><Bell className="w-3 h-3" />{(p as any).alerts} alerts</span>}
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>

                  {/* Selected patient detail */}
                  {selectedPatient && (
                    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
                      <div className="flex justify-between items-center mb-4">
                        <h3 className="font-bold text-slate-200 flex items-center gap-2">
                          <TrendingUp className="w-4 h-4 text-blue-400" />
                          {selectedPatient.name} — Risk Trend (24h)
                        </h3>
                        <div className="flex items-center gap-1 text-xs text-slate-500">
                          <RefreshCw className="w-3 h-3" /> Updated {selectedPatient.lastUpdate}
                        </div>
                      </div>
                      <div className="h-44">
                        <ResponsiveContainer width="100%" height="100%">
                          <AreaChart data={vitalsHistory} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                            <defs>
                              <linearGradient id="nrG" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                              </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                            <XAxis dataKey="time" stroke="#475569" fontSize={11} tickLine={false} axisLine={false} />
                            <YAxis stroke="#475569" fontSize={11} tickLine={false} axisLine={false} domain={[0, 100]} unit="%" />
                            <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', fontSize: 12 }} formatter={(v: any) => [`${v}%`, 'Risk Score']} />
                            <Area type="monotone" dataKey="risk" stroke="#3b82f6" strokeWidth={2} fillOpacity={1} fill="url(#nrG)" dot={{ fill: '#3b82f6', r: 3 }} />
                          </AreaChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {tab === 'upload' && (
                <div className="max-w-2xl space-y-4">
                  {/* Mode Toggle */}
                  <div className="flex gap-1 bg-slate-900 border border-slate-800 rounded-xl p-1 w-fit">
                    <button onClick={() => setLabEntryMode('manual')}
                      className={cn('flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold transition-all',
                        labEntryMode === 'manual' ? 'bg-blue-600 text-white shadow' : 'text-slate-400 hover:text-white hover:bg-slate-800')}>
                      <ClipboardList className="w-3.5 h-3.5" /> Manual Entry
                    </button>
                    <button onClick={() => setLabEntryMode('pdf')}
                      className={cn('flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold transition-all',
                        labEntryMode === 'pdf' ? 'bg-blue-600 text-white shadow' : 'text-slate-400 hover:text-white hover:bg-slate-800')}>
                      <FileUp className="w-3.5 h-3.5" /> Upload PDF Report
                    </button>
                  </div>

                  <AnimatePresence mode="wait">
                    {labEntryMode === 'manual' ? (
                      <motion.div key="manual" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.15 }}>
                        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
                          <div className="flex items-center gap-3 mb-6">
                            <div className="w-10 h-10 rounded-xl bg-blue-900/60 border border-blue-700 flex items-center justify-center">
                              <Syringe className="w-5 h-5 text-blue-300" />
                            </div>
                            <div>
                              <h3 className="font-bold text-slate-100">Enter Blood Test Results</h3>
                              <p className="text-xs text-slate-500">Results will immediately update the patient's risk score</p>
                            </div>
                          </div>

                          <AnimatePresence>
                            {submitted && (
                              <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                                className="mb-5 p-3 rounded-lg bg-emerald-950/60 border border-emerald-700 flex items-center gap-2 text-emerald-300 text-sm">
                                <Check className="w-4 h-4 shrink-0" />
                                Lab results submitted successfully. Risk model will update in 2–3 minutes.
                              </motion.div>
                            )}
                          </AnimatePresence>

                          <form onSubmit={handleSubmitLab} className="space-y-5">
                            <div>
                              <label className="text-xs font-semibold text-slate-400 mb-1.5 block">Select Patient</label>
                              <select value={labForm.patient} onChange={e => setLabForm(f => ({ ...f, patient: e.target.value }))}
                                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2.5 text-sm text-slate-200 focus:outline-none focus:border-blue-600">
                                {patients.map(p => <option key={p.id} value={p.id}>{p.id} — {p.name} ({p.bed})</option>)}
                              </select>
                            </div>

                            <div>
                              <p className="text-xs font-semibold text-slate-400 mb-3">Critical Markers</p>
                              <div className="grid grid-cols-2 gap-4">
                                {[
                                  { key: 'lactate',    label: 'Serum Lactate', unit: 'mmol/L', ref: 'Normal: 0.5–2.2',  alert: true  },
                                  { key: 'wbc',        label: 'WBC Count',     unit: '10⁹/L',  ref: 'Normal: 4.5–11.0', alert: true  },
                                  { key: 'creatinine', label: 'Creatinine',    unit: 'mg/dL',  ref: 'Normal: 0.6–1.2',  alert: false },
                                  { key: 'platelets',  label: 'Platelets',     unit: '10⁹/L',  ref: 'Normal: 150–400',  alert: false },
                                  { key: 'hemoglobin', label: 'Hemoglobin',    unit: 'g/dL',   ref: 'Normal: 12–17.5',  alert: false },
                                  { key: 'sodium',     label: 'Sodium',        unit: 'mEq/L',  ref: 'Normal: 136–145',  alert: false },
                                ].map(field => (
                                  <div key={field.key}>
                                    <label className="text-xs font-medium text-slate-400 mb-1 flex items-center gap-1">
                                      {field.label}
                                      {field.alert && <span className="text-[10px] text-red-400 font-bold">CRITICAL</span>}
                                    </label>
                                    <div className="relative">
                                      <input type="number" step="0.1" placeholder="—"
                                        value={(labForm as any)[field.key]}
                                        onChange={e => setLabForm(f => ({ ...f, [field.key]: e.target.value }))}
                                        className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-blue-600 pr-14"
                                      />
                                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-600">{field.unit}</span>
                                    </div>
                                    <p className="text-[10px] text-slate-600 mt-0.5">{field.ref}</p>
                                  </div>
                                ))}
                              </div>
                            </div>

                            <div>
                              <label className="text-xs font-semibold text-slate-400 mb-1.5 block">Clinical Notes (optional)</label>
                              <textarea rows={3} placeholder="Any relevant observations or context..."
                                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-blue-600 resize-none" />
                            </div>

                            <button type="submit" disabled={submitting}
                              className={cn('w-full py-3 rounded-xl font-semibold text-white text-sm flex items-center justify-center gap-2 transition-all',
                                submitting ? 'bg-blue-800 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-500 shadow-lg shadow-blue-900/30')}>
                              {submitting ? (
                                <><svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Submitting Results...</>
                              ) : (
                                <><Upload className="w-4 h-4" /> Submit Lab Results</>
                              )}
                            </button>
                          </form>
                        </div>
                      </motion.div>
                    ) : (
                      <motion.div key="pdf" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.15 }}>
                        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-5">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-xl bg-violet-900/60 border border-violet-700 flex items-center justify-center">
                              <FileUp className="w-5 h-5 text-violet-300" />
                            </div>
                            <div>
                              <h3 className="font-bold text-slate-100">Upload Blood Test PDF Report</h3>
                              <p className="text-xs text-slate-500">Upload a lab report PDF — the system will extract and link the results automatically</p>
                            </div>
                          </div>

                          <AnimatePresence>
                            {pdfUploaded && (
                              <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                                className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-700 flex items-center gap-2 text-emerald-300 text-sm">
                                <Check className="w-4 h-4 shrink-0" />
                                PDF uploaded and processed successfully. Lab values extracted and linked to the patient record.
                              </motion.div>
                            )}
                          </AnimatePresence>

                          <div>
                            <label className="text-xs font-semibold text-slate-400 mb-1.5 block">Select Patient</label>
                            <select value={labForm.patient} onChange={e => setLabForm(f => ({ ...f, patient: e.target.value }))}
                              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2.5 text-sm text-slate-200 focus:outline-none focus:border-blue-600">
                              {patients.map(p => <option key={p.id} value={p.id}>{p.id} — {p.name} ({p.bed})</option>)}
                            </select>
                          </div>

                          {/* Drop zone */}
                          <div
                            onDragOver={e => { e.preventDefault(); setPdfDragging(true); }}
                            onDragLeave={() => setPdfDragging(false)}
                            onDrop={handlePdfDrop}
                            className={cn(
                              'relative border-2 border-dashed rounded-xl p-10 text-center transition-all cursor-pointer',
                              pdfDragging ? 'border-blue-500 bg-blue-950/30' : pdfFile ? 'border-emerald-600 bg-emerald-950/20' : 'border-slate-700 hover:border-slate-500 hover:bg-slate-800/30'
                            )}
                            onClick={() => document.getElementById('pdf-input')?.click()}
                          >
                            <input id="pdf-input" type="file" accept="application/pdf" className="hidden" onChange={handlePdfChange} />

                            {pdfFile ? (
                              <div className="space-y-2">
                                <div className="w-14 h-14 mx-auto rounded-2xl bg-emerald-900/50 border border-emerald-700 flex items-center justify-center">
                                  <FileText className="w-7 h-7 text-emerald-400" />
                                </div>
                                <p className="font-semibold text-emerald-300 text-sm">{pdfFile.name}</p>
                                <p className="text-xs text-slate-500">{(pdfFile.size / 1024).toFixed(1)} KB · PDF</p>
                                <button
                                  onClick={e => { e.stopPropagation(); setPdfFile(null); }}
                                  className="inline-flex items-center gap-1 text-xs text-red-400 hover:text-red-300 mt-1">
                                  <X className="w-3 h-3" /> Remove file
                                </button>
                              </div>
                            ) : (
                              <div className="space-y-3">
                                <div className="w-14 h-14 mx-auto rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center">
                                  <FileUp className="w-7 h-7 text-slate-500" />
                                </div>
                                <div>
                                  <p className="font-semibold text-slate-300 text-sm">Drag & drop a PDF here</p>
                                  <p className="text-xs text-slate-500 mt-1">or click to browse files</p>
                                </div>
                                <p className="text-[11px] text-slate-600">Accepted format: PDF · Max size: 20 MB</p>
                              </div>
                            )}
                          </div>

                          <div className="p-3 rounded-lg bg-slate-800/50 border border-slate-700 text-xs text-slate-400 space-y-1">
                            <p className="font-semibold text-slate-300 flex items-center gap-1.5"><Info className="w-3.5 h-3.5 text-blue-400" /> What gets extracted automatically:</p>
                            <p>Serum Lactate · WBC Count · Creatinine · Platelets · Hemoglobin · Procalcitonin · CRP · Bilirubin · Sodium</p>
                          </div>

                          <button onClick={handlePdfSubmit} disabled={!pdfFile || pdfUploading}
                            className={cn('w-full py-3 rounded-xl font-semibold text-white text-sm flex items-center justify-center gap-2 transition-all',
                              !pdfFile ? 'bg-slate-800 text-slate-500 cursor-not-allowed' :
                              pdfUploading ? 'bg-violet-800 cursor-not-allowed' :
                              'bg-violet-600 hover:bg-violet-500 shadow-lg shadow-violet-900/30')}>
                            {pdfUploading ? (
                              <><svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Processing PDF...</>
                            ) : (
                              <><Upload className="w-4 h-4" /> Upload & Process Report</>
                            )}
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              )}

              {tab === 'alerts' && (
                <div className="space-y-3 max-w-3xl">
                  <div className="grid grid-cols-3 gap-4 mb-2">
                    {[
                      { label: 'Critical', count: 2, color: 'text-red-400 bg-red-950/40 border-red-800' },
                      { label: 'High', count: 2, color: 'text-orange-400 bg-orange-950/40 border-orange-800' },
                      { label: 'Total', count: alerts.length, color: 'text-slate-200 bg-slate-900 border-slate-700' },
                    ].map((s, i) => (
                      <div key={i} className={cn('p-4 rounded-xl border flex justify-between items-center', s.color)}>
                        <div>
                          <p className="text-xs text-slate-500">{s.label}</p>
                          <p className={cn('text-2xl font-bold', s.color.split(' ')[0])}>{s.count}</p>
                        </div>
                        <Bell className={cn('w-6 h-6 opacity-40', s.color.split(' ')[0])} />
                      </div>
                    ))}
                  </div>
                  {alerts.map(alert => (
                    <div key={alert.id} className={cn(
                      'p-4 rounded-xl border flex items-start justify-between gap-4',
                      alert.severity === 'critical' ? 'bg-red-950/30 border-red-800/50' :
                      alert.severity === 'high' ? 'bg-orange-950/20 border-orange-800/40' :
                      alert.severity === 'medium' ? 'bg-amber-950/10 border-amber-800/30' :
                      'bg-slate-900 border-slate-800')}>
                      <div className="flex gap-3 flex-1">
                        <div className="mt-0.5 shrink-0">
                          {alert.severity === 'critical' && <AlertCircle className="w-5 h-5 text-red-400" />}
                          {alert.severity === 'high' && <TriangleAlert className="w-5 h-5 text-orange-400" />}
                          {alert.severity === 'medium' && <Info className="w-5 h-5 text-amber-400" />}
                          {alert.severity === 'low' && <Bell className="w-5 h-5 text-slate-500" />}
                        </div>
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-bold text-slate-200 text-sm">{alert.patientId}</span>
                            <span className="text-xs text-slate-500 flex items-center gap-1"><Clock className="w-3 h-3" />{alert.time}</span>
                          </div>
                          <p className={cn('text-sm', alert.severity === 'critical' ? 'text-red-300 font-medium' : 'text-slate-300')}>{alert.message}</p>
                        </div>
                      </div>
                      {(alert.severity === 'critical' || alert.severity === 'high') && (
                        <button className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-medium rounded-lg border border-slate-600 transition-colors shrink-0">
                          Acknowledge
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}

            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
