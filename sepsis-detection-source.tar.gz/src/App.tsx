import { Switch, Route, Router as WouterRouter, Redirect } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { Home } from "@/pages/Home";
import { LoginPage } from "@/pages/LoginPage";
import { DoctorDashboard } from "@/pages/DoctorDashboard";
import { NurseDashboard } from "@/pages/NurseDashboard";
import { AuthProvider, useAuth } from "@/context/AuthContext";

const queryClient = new QueryClient();

function ProtectedRoute({ component: Component, role }: { component: React.ComponentType; role?: string }) {
  const { isAuthenticated, user } = useAuth();
  if (!isAuthenticated) return <Redirect to="/login" />;
  if (role && user?.role !== role) return <Redirect to={user?.role === 'doctor' ? '/dashboard/doctor' : '/dashboard/nurse'} />;
  return <Component />;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/login" component={LoginPage} />
      <Route path="/dashboard/doctor">
        {() => <ProtectedRoute component={DoctorDashboard} role="doctor" />}
      </Route>
      <Route path="/dashboard/nurse">
        {() => <ProtectedRoute component={NurseDashboard} role="nurse" />}
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
