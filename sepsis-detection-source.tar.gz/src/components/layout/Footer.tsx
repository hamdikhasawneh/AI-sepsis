import { Activity, Github, FileText, Mail } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-foreground text-background py-16 border-t border-border/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 lg:gap-8">
          
          <div className="md:col-span-2 space-y-6">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-primary to-blue-400 flex items-center justify-center shadow-lg shadow-primary/20">
                <Activity className="w-6 h-6 text-white" />
              </div>
              <span className="font-display font-bold text-2xl tracking-tight text-white">
                Sepsis<span className="text-primary">AI</span>
              </span>
            </div>
            <p className="text-slate-400 text-sm max-w-sm leading-relaxed">
              An AI-Assisted ICU Sepsis Detection System for early warning and clinical decision support. 
              Developed as a graduation project for the Department of Computer Science.
            </p>
            <div className="flex gap-4">
              <button className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-slate-300 hover:bg-primary hover:text-white transition-colors">
                <Github className="w-5 h-5" />
              </button>
              <button className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-slate-300 hover:bg-primary hover:text-white transition-colors">
                <FileText className="w-5 h-5" />
              </button>
              <button className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-slate-300 hover:bg-primary hover:text-white transition-colors">
                <Mail className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div>
            <h4 className="font-display font-semibold text-white mb-6 text-lg">Project Sections</h4>
            <ul className="space-y-3 text-sm text-slate-400">
              <li><a href="#overview" className="hover:text-primary transition-colors">Overview</a></li>
              <li><a href="#features" className="hover:text-primary transition-colors">Key Features</a></li>
              <li><a href="#architecture" className="hover:text-primary transition-colors">System Architecture</a></li>
              <li><a href="#dashboard" className="hover:text-primary transition-colors">Interactive Demo</a></li>
              <li><a href="#models" className="hover:text-primary transition-colors">AI Models</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display font-semibold text-white mb-6 text-lg">Acknowledgments</h4>
            <ul className="space-y-4 text-sm text-slate-400">
              <li className="flex flex-col">
                <span className="text-white font-medium">Supervised By</span>
                <span>Dr. Bushra Alhijawi</span>
              </li>
              <li className="flex flex-col mt-4">
                <span className="text-white font-medium">Dataset</span>
                <span>MIMIC-IV Clinical Database</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-slate-500">
          <p>© {new Date().getFullYear()} AI-Assisted ICU Sepsis Detection System. All rights reserved.</p>
          <div className="flex gap-6">
            <span>Hamdi Khasawneh</span>
            <span>Hamza Ithiab</span>
            <span>Waleed AlHasan</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
