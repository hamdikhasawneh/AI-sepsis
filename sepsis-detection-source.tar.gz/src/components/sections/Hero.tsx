import { motion } from 'framer-motion';
import { ArrowRight, Activity, ShieldAlert, BrainCircuit, HeartPulse, LineChart } from 'lucide-react';
import { cn } from '@/lib/utils';

export function Hero() {
  return (
    <section className="relative min-h-screen pt-32 pb-20 flex items-center overflow-hidden bg-background">
      {/* Background Graphic */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-[-10%] right-[-5%] w-[800px] h-[800px] rounded-full bg-primary/5 blur-[120px]" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[600px] h-[600px] rounded-full bg-teal-500/5 blur-[100px]" />
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-[0.015] mix-blend-overlay" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          
          {/* Left Text Column */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="max-w-2xl"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary font-medium text-sm mb-6 border border-primary/20">
              <Activity className="w-4 h-4" />
              <span>Graduation Project Showcase</span>
            </div>
            
            <h1 className="text-5xl lg:text-6xl font-display font-bold leading-[1.1] tracking-tight mb-6">
              AI-Assisted ICU <br/>
              <span className="text-gradient">Sepsis Detection</span> System
            </h1>
            
            <p className="text-xl text-muted-foreground mb-8 leading-relaxed font-light">
              Early detection of sepsis in intensive care units using advanced machine learning. 
              Real-time risk prediction, vital trend monitoring, and explainable AI for safer, faster clinical decision-making.
            </p>
            
            <div className="flex flex-wrap gap-4 mb-12">
              <a href="#dashboard" className="px-8 py-4 rounded-xl font-semibold bg-gradient-to-r from-primary to-blue-500 text-white shadow-xl shadow-primary/25 hover:shadow-2xl hover:shadow-primary/30 hover:-translate-y-0.5 transition-all duration-300 flex items-center gap-2 group">
                View Dashboard Demo
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </a>
              <a href="#overview" className="px-8 py-4 rounded-xl font-semibold bg-white text-foreground border border-border shadow-sm hover:shadow-md hover:border-primary/30 transition-all duration-300 flex items-center gap-2">
                Explore Project
              </a>
            </div>

            <div className="flex flex-wrap items-center gap-x-8 gap-y-4 text-sm font-medium text-muted-foreground">
              <div className="flex items-center gap-2"><ShieldAlert className="w-4 h-4 text-primary" /> Real-Time Alerts</div>
              <div className="flex items-center gap-2"><BrainCircuit className="w-4 h-4 text-primary" /> SHAP Explainability</div>
              <div className="flex items-center gap-2"><LineChart className="w-4 h-4 text-primary" /> Temporal Modeling</div>
            </div>
          </motion.div>

          {/* Right Visual Column - Floating Mock UI */}
          <div className="relative h-[600px] hidden lg:block">
            {/* Center Main Card */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, delay: 0.2 }}
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 glass-card p-6 rounded-2xl z-20"
            >
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h3 className="font-bold text-lg">Patient ICU-003</h3>
                  <p className="text-sm text-muted-foreground">James Harrison • Bed 7C</p>
                </div>
                <div className="w-3 h-3 rounded-full bg-critical animate-pulse" />
              </div>

              <div className="text-center mb-6">
                <p className="text-sm font-medium text-muted-foreground mb-1">Sepsis Risk Score</p>
                <div className="text-6xl font-display font-bold text-critical tracking-tighter">82<span className="text-3xl">%</span></div>
                <div className="inline-flex mt-3 px-3 py-1 bg-critical/10 text-critical rounded-full text-xs font-bold uppercase tracking-wider border border-critical/20">
                  Critical Level
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between text-sm p-3 rounded-lg bg-background/50 border border-border/50">
                  <span className="text-muted-foreground">Lactate</span>
                  <span className="font-bold text-critical">3.8 mmol/L <span className="text-xs">↑</span></span>
                </div>
                <div className="flex justify-between text-sm p-3 rounded-lg bg-background/50 border border-border/50">
                  <span className="text-muted-foreground">Heart Rate</span>
                  <span className="font-bold text-high">118 bpm <span className="text-xs">↑</span></span>
                </div>
              </div>
            </motion.div>

            {/* Floating Element 1 */}
            <motion.div 
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.5 }}
              className="absolute top-20 left-0 glass-card p-4 rounded-xl z-30 flex items-center gap-4 animate-float"
            >
              <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                <HeartPulse className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground font-medium">Continuous Processing</p>
                <p className="text-sm font-bold">MIMIC-IV Streams</p>
              </div>
            </motion.div>

            {/* Floating Element 2 */}
            <motion.div 
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.7 }}
              className="absolute bottom-32 right-[-20px] glass-card p-4 rounded-xl z-30 flex items-center gap-4 animate-float-delayed"
            >
               <div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center">
                <BrainCircuit className="w-5 h-5 text-amber-600" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground font-medium">Model Inference</p>
                <p className="text-sm font-bold">LSTM Time-Series</p>
              </div>
            </motion.div>
          </div>

        </div>
      </div>
    </section>
  );
}
