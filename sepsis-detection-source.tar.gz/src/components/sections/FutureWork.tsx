import { motion } from 'framer-motion';
import {
  Hospital, Globe, FlaskConical, Smartphone, HeartHandshake,
  Languages, Sliders, Server
} from 'lucide-react';

const futureItems = [
  {
    icon: Hospital,
    title: 'Live Hospital Integration',
    desc: 'Connect directly to hospital EHR systems and ICU monitoring devices for real-time data ingestion in clinical environments.',
  },
  {
    icon: Globe,
    title: 'External Dataset Validation',
    desc: 'Validate model generalizability on external ICU datasets such as eICU-CRD, Amsterdam UMCdb, and international cohorts.',
  },
  {
    icon: FlaskConical,
    title: 'Prospective Clinical Testing',
    desc: 'Conduct controlled clinical trials to evaluate the system\'s impact on early sepsis recognition and patient outcomes in real ICUs.',
  },
  {
    icon: Smartphone,
    title: 'Mobile Alert Support',
    desc: 'Extend the alert system to mobile devices, enabling clinicians to receive critical patient notifications anywhere in the hospital.',
  },
  {
    icon: HeartHandshake,
    title: 'Advanced Organ-Failure Forecasting',
    desc: 'Expand beyond sepsis risk to predict individual organ failure (renal, hepatic, respiratory) with separate dedicated models.',
  },
  {
    icon: Languages,
    title: 'Multilingual Clinician Interface',
    desc: 'Localize the dashboard interface for Arabic, French, and other languages to support clinicians in diverse healthcare settings.',
  },
  {
    icon: Sliders,
    title: 'Model Calibration & Personalization',
    desc: 'Implement patient-specific calibration to improve risk score reliability for different demographic groups and comorbidity profiles.',
  },
  {
    icon: Server,
    title: 'Hospital Infrastructure Deployment',
    desc: 'Package the system for on-premise hospital deployment with containerization, data privacy controls, and HL7/FHIR integration.',
  },
];

export function FutureWork() {
  return (
    <section id="future" className="py-24 bg-gradient-to-br from-slate-900 to-blue-950 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,_var(--tw-gradient-stops))] from-blue-800/20 via-transparent to-transparent" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">

        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 text-white font-medium text-sm mb-4 border border-white/20">
            Looking Ahead
          </div>
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-4 text-white">
            Future Directions
          </h2>
          <p className="text-lg text-slate-400">
            The current system establishes a strong foundation. These extensions would move it toward clinical deployment and broader impact.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {futureItems.map((item, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.06 }}
              className="p-5 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20 transition-all group"
            >
              <div className="w-11 h-11 rounded-xl bg-blue-500/20 border border-blue-400/30 flex items-center justify-center mb-4 text-blue-300 group-hover:bg-blue-500/30 transition-colors">
                <item.icon className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-white mb-2 leading-snug">{item.title}</h3>
              <p className="text-sm text-slate-400 leading-relaxed">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
