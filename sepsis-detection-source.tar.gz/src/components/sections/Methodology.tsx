import { motion } from 'framer-motion';
import { Database, FileText, Pill, Activity, AlertCircle } from 'lucide-react';

const dataSources = [
  { icon: Activity, name: "Vital Signs", desc: "HR, BP, SpO2, Temp, RR" },
  { icon: FileText, name: "Lab Events", desc: "Lactate, WBC, Creatinine, Bilirubin" },
  { icon: Pill, name: "Prescriptions", desc: "Antibiotics, Vasopressors" },
  { icon: Database, name: "Demographics", desc: "Age, Gender, Weight" },
];

export function Methodology() {
  return (
    <section id="methodology" className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-6">Data & Methodology</h2>
          <p className="text-lg text-muted-foreground">
            Built on the rigorous MIMIC-IV clinical database, employing robust preprocessing to handle real-world ICU data challenges.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          
          <motion.div initial={{opacity:0, x:-20}} whileInView={{opacity:1, x:0}} viewport={{once:true}} className="bg-white rounded-2xl p-8 border border-border shadow-sm">
            <div className="inline-block px-3 py-1 bg-primary/10 text-primary rounded-full text-xs font-bold tracking-wide mb-4">DATASET</div>
            <h3 className="text-2xl font-display font-bold mb-4">MIMIC-IV v2.2</h3>
            <p className="text-slate-600 mb-6 leading-relaxed">
              We utilized the Medical Information Mart for Intensive Care (MIMIC-IV), extracting records from adult patients to construct a robust cohort for early sepsis warning within the first 24 hours of admission.
            </p>
            
            <h4 className="font-semibold mb-4 text-slate-800">Primary Features Included:</h4>
            <div className="grid grid-cols-2 gap-4">
              {dataSources.map((source, idx) => (
                <div key={idx} className="flex gap-3 items-start p-3 bg-slate-50 rounded-lg">
                  <source.icon className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-sm text-slate-900">{source.name}</p>
                    <p className="text-xs text-slate-500">{source.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div initial={{opacity:0, x:20}} whileInView={{opacity:1, x:0}} viewport={{once:true}} className="bg-white rounded-2xl p-8 border border-border shadow-sm">
            <div className="inline-block px-3 py-1 bg-amber-500/10 text-amber-600 rounded-full text-xs font-bold tracking-wide mb-4">CHALLENGES</div>
            <h3 className="text-2xl font-display font-bold mb-4">Preprocessing Pipeline</h3>
            <p className="text-slate-600 mb-6 leading-relaxed">
              Real-world clinical data is notoriously messy. Our data engineering pipeline solves critical temporal and structural issues before inference.
            </p>

            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-semibold text-sm">Irregular Sampling & Missing Values</h4>
                  <p className="text-sm text-slate-500">Addressed using forward-filling (LOCF) for vital signs and specialized imputation for sparse lab results.</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-semibold text-sm">Outlier Rejection</h4>
                  <p className="text-sm text-slate-500">Physiologically impossible values filtered using established clinical bounds (e.g., HR &lt; 0 or HR &gt; 300).</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-semibold text-sm">Sepsis Labeling (Sepsis-3)</h4>
                  <p className="text-sm text-slate-500">Labels defined precisely using the Sepsis-3 criteria (suspected infection + SOFA score increase ≥ 2).</p>
                </div>
              </li>
            </ul>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
