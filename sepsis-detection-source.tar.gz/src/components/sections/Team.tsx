import { motion } from 'framer-motion';

const team = [
  { name: "Hamdi Khasawneh", role: "Data & Evaluation", desc: "Data Engineering, Feature Pipeline, Model Evaluation, Documentation" },
  { name: "Hamza Ithiab", role: "ML Engineering", desc: "ML/DL Model Development, LSTM & Transformer Implementation, Benchmarking" },
  { name: "Waleed AlHasan", role: "Frontend & UI/UX", desc: "Dashboard Design, React Frontend, SHAP Interface, System Testing" },
];

export function Team() {
  return (
    <section id="team" className="py-24 bg-white border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-6">The Project Team</h2>
          <p className="text-lg text-muted-foreground">
            A multidisciplinary effort bringing together data science, machine learning, and software engineering.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {team.map((member, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="text-center group"
            >
              <div className="w-24 h-24 mx-auto bg-slate-100 rounded-full border-4 border-white shadow-lg mb-4 flex items-center justify-center text-2xl font-bold text-slate-400 group-hover:bg-primary/5 group-hover:text-primary transition-colors">
                {member.name.split(' ').map(n => n[0]).join('')}
              </div>
              <h3 className="text-xl font-bold">{member.name}</h3>
              <p className="text-sm font-semibold text-primary mb-3">{member.role}</p>
              <p className="text-sm text-slate-500">{member.desc}</p>
            </motion.div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <div className="inline-block p-6 rounded-2xl bg-slate-50 border border-slate-200">
            <p className="text-sm text-slate-500 font-medium uppercase tracking-wider mb-2">Project Supervisor</p>
            <h3 className="text-xl font-bold text-slate-900">Dr. Bushra Alhijawi</h3>
            <p className="text-sm text-slate-600 mt-1">Academic Supervision, Research Guidance & Expert Review</p>
          </div>
        </div>

      </div>
    </section>
  );
}
