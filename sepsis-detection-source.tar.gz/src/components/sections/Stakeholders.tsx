import { motion } from 'framer-motion';
import { Stethoscope, UserCog, Building2, Server, FlaskConical } from 'lucide-react';

const stakeholders = [
  {
    icon: Stethoscope,
    title: 'ICU Physicians',
    color: 'bg-blue-100 text-blue-600',
    borderColor: 'border-blue-200',
    benefits: [
      'Real-time sepsis risk scores for each patient',
      'Trend charts for vitals and lab values over time',
      'SHAP-based explanations of model decisions',
      'Prioritized patient list by risk level',
      'Alert history and clinical timeline',
    ],
  },
  {
    icon: UserCog,
    title: 'ICU Nurses',
    color: 'bg-teal-100 text-teal-600',
    borderColor: 'border-teal-200',
    benefits: [
      'Simplified patient monitoring dashboard',
      'Easy blood test result upload interface',
      'Clear alert notifications with severity levels',
      'Automatic patient prioritization for urgent care',
      'Last update timestamps for each patient',
    ],
  },
  {
    icon: Building2,
    title: 'Hospital Administrators',
    color: 'bg-purple-100 text-purple-600',
    borderColor: 'border-purple-200',
    benefits: [
      'ICU-wide patient risk overview',
      'Audit-ready alert and decision logs',
      'Role-based access control and security',
      'System performance and usage reporting',
      'Supports integration with existing hospital workflows',
    ],
  },
  {
    icon: Server,
    title: 'IT & Technical Support',
    color: 'bg-amber-100 text-amber-600',
    borderColor: 'border-amber-200',
    benefits: [
      'Modular, well-documented codebase',
      'Separated training and deployment pipelines',
      'File-based and SQL-based storage flexibility',
      'REST API architecture for easy integration',
      'Clear system and technical documentation',
    ],
  },
  {
    icon: FlaskConical,
    title: 'Researchers & Data Scientists',
    color: 'bg-rose-100 text-rose-600',
    borderColor: 'border-rose-200',
    benefits: [
      'MIMIC-IV–based reproducible pipeline',
      'Modular feature engineering and labeling',
      'Model comparison framework (LR, RF, LSTM, XGBoost)',
      'SHAP explainability integrated end-to-end',
      'Experiment logs and benchmarking reports',
    ],
  },
];

export function Stakeholders() {
  return (
    <section id="stakeholders" className="py-24 bg-white border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary font-medium text-sm mb-4 border border-primary/20">
            Target Users
          </div>
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">
            Designed for Every Role in the ICU
          </h2>
          <p className="text-lg text-muted-foreground">
            SepsisAI serves clinicians, administrators, and researchers with role-specific views and tailored insights.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {stakeholders.map((s, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.08 }}
              className={`p-6 rounded-2xl border ${s.borderColor} bg-white shadow-sm hover:shadow-md transition-all group`}
            >
              <div className={`w-12 h-12 rounded-xl ${s.color} flex items-center justify-center mb-4`}>
                <s.icon className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold mb-3 group-hover:text-primary transition-colors">{s.title}</h3>
              <ul className="space-y-2">
                {s.benefits.map((b, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                    <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-primary shrink-0" />
                    {b}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
