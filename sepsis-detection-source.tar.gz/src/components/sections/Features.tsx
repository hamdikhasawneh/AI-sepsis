import { motion } from 'framer-motion';
import { Brain, HeartPulse, TrendingUp, BellRing, Lightbulb, ShieldCheck, History, Layers, Lock, LayoutDashboard } from 'lucide-react';

const features = [
  { icon: Brain, title: "Real-Time Risk Prediction", desc: "Continuous calculation of sepsis probability using live ICU feeds." },
  { icon: HeartPulse, title: "Continuous Monitoring", desc: "Automated tracking of patient status without manual intervention." },
  { icon: TrendingUp, title: "Trend Visualization", desc: "Interactive charts showing the trajectory of vitals and lab results." },
  { icon: BellRing, title: "High-Risk Alerts", desc: "Severity-tiered notifications to draw immediate clinical attention." },
  { icon: Lightbulb, title: "Explainable AI (SHAP)", desc: "Transparent reasoning showing exactly which clinical features drove the score." },
  { icon: ShieldCheck, title: "Role-Based Access", desc: "Distinct, optimized dashboards tailored for Doctors vs. Nurses." },
  { icon: History, title: "Patient Risk History", desc: "Retrospective view of risk scores over the entire ICU stay." },
  { icon: Layers, title: "Modular Architecture", desc: "Separation of inference engine and frontend for scalable deployment." },
  { icon: Lock, title: "Secure Data Handling", desc: "Designed for de-identified data processing compliant with privacy standards." },
  { icon: LayoutDashboard, title: "Clinician-Friendly UI", desc: "Clean, low-cognitive-load interface to prevent alert fatigue." },
];

export function Features() {
  return (
    <section id="features" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-6">Core Capabilities</h2>
          <p className="text-lg text-muted-foreground">
            A comprehensive suite of tools designed specifically for the high-pressure intensive care environment.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feat, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: (idx % 3) * 0.1 }}
              className="p-6 rounded-2xl bg-background border border-border/60 hover:shadow-xl hover:border-primary/30 transition-all duration-300 group"
            >
              <div className="w-12 h-12 rounded-xl bg-slate-50 flex items-center justify-center mb-5 group-hover:bg-primary/10 transition-colors">
                <feat.icon className="w-6 h-6 text-slate-600 group-hover:text-primary transition-colors" />
              </div>
              <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">{feat.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{feat.desc}</p>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
