import { motion } from 'framer-motion';
import {
  Database, Cpu, Rocket, LayoutDashboard, Lightbulb,
  BarChart2, ClipboardList, BookOpen, FileCode2, Scroll
} from 'lucide-react';

const deliverables = [
  {
    icon: Database,
    title: 'Data Engineering Pipeline',
    desc: 'End-to-end pipeline for MIMIC-IV ingestion, cleaning, merging, and feature extraction across all ICU data tables.',
    color: 'text-blue-600',
    bg: 'bg-blue-50',
  },
  {
    icon: Cpu,
    title: 'Model Training Pipeline',
    desc: 'Reproducible training scripts for Logistic Regression, Random Forest, Gradient Boosting, XGBoost, LSTM, and Transformer models.',
    color: 'text-violet-600',
    bg: 'bg-violet-50',
  },
  {
    icon: Rocket,
    title: 'Deployment Pipeline',
    desc: 'Modular inference engine for loading trained models and running online predictions on incoming ICU data streams.',
    color: 'text-rose-600',
    bg: 'bg-rose-50',
  },
  {
    icon: LayoutDashboard,
    title: 'Web-Based Dashboard',
    desc: 'Full-stack role-based web application with Doctor and Nurse views, patient detail panels, alert management, and trend charts.',
    color: 'text-teal-600',
    bg: 'bg-teal-50',
  },
  {
    icon: Lightbulb,
    title: 'Explainability Module',
    desc: 'On-demand SHAP value computation and visualization, with clinical interpretation of top contributing risk factors per patient.',
    color: 'text-amber-600',
    bg: 'bg-amber-50',
  },
  {
    icon: BarChart2,
    title: 'Benchmarking Report',
    desc: 'Comprehensive evaluation of all models across AUROC, AUPRC, Sensitivity, Specificity, and F1 metrics with comparative analysis.',
    color: 'text-green-600',
    bg: 'bg-green-50',
  },
  {
    icon: ClipboardList,
    title: 'Experiment Logs',
    desc: 'Tracked hyperparameter configurations, training runs, cross-validation results, and performance curves for reproducibility.',
    color: 'text-orange-600',
    bg: 'bg-orange-50',
  },
  {
    icon: BookOpen,
    title: 'User Documentation',
    desc: 'Clinician-facing user guide explaining how to use the Doctor and Nurse dashboards, interpret alerts, and understand risk scores.',
    color: 'text-indigo-600',
    bg: 'bg-indigo-50',
  },
  {
    icon: FileCode2,
    title: 'System Documentation',
    desc: 'Architecture documentation covering service design, data flow, API structure, storage schema, and deployment configuration.',
    color: 'text-cyan-600',
    bg: 'bg-cyan-50',
  },
  {
    icon: Scroll,
    title: 'Technical Documentation',
    desc: 'Developer reference for the preprocessing, feature engineering, model inference, and explainability modules.',
    color: 'text-slate-600',
    bg: 'bg-slate-100',
  },
];

export function Deliverables() {
  return (
    <section id="deliverables" className="py-24 bg-white border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary font-medium text-sm mb-4 border border-primary/20">
            Academic & Technical Output
          </div>
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">
            Research Deliverables
          </h2>
          <p className="text-lg text-muted-foreground">
            A complete set of engineered artifacts, documented pipelines, and research outputs produced throughout this graduation project.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {deliverables.map((d, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.05 }}
              className="p-5 rounded-2xl border border-border bg-white hover:shadow-md hover:-translate-y-0.5 transition-all group"
            >
              <div className={`w-10 h-10 rounded-xl ${d.bg} flex items-center justify-center mb-3 ${d.color}`}>
                <d.icon className="w-5 h-5" />
              </div>
              <h3 className={`text-sm font-bold mb-2 group-hover:${d.color} transition-colors leading-snug`}>{d.title}</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">{d.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
