import { motion } from 'framer-motion';
import { Clock, AlertTriangle, ActivitySquare, Database } from 'lucide-react';

const stats = [
  { value: "1 in 3", label: "Hospital deaths involve sepsis", icon: AlertTriangle, color: "text-red-500", bg: "bg-red-50" },
  { value: "18.2M", label: "Global sepsis cases per year", icon: ActivitySquare, color: "text-blue-500", bg: "bg-blue-50" },
  { value: "~7 hrs", label: "Average delay to detection", icon: Clock, color: "text-orange-500", bg: "bg-orange-50" },
  { value: "7%", label: "Mortality rise per hour delayed", icon: Database, color: "text-purple-500", bg: "bg-purple-50" },
];

export function Problem() {
  return (
    <section id="problem" className="py-24 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-6">Why Sepsis Demands Immediate Action</h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Sepsis is a life-threatening organ dysfunction caused by a dysregulated host response to infection. 
            In the ICU, every minute counts, but traditional scoring systems often detect it too late.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-background rounded-2xl p-6 border border-border/50 shadow-lg shadow-black/[0.02] hover:shadow-xl transition-all duration-300"
            >
              <div className={`w-12 h-12 rounded-xl ${stat.bg} ${stat.color} flex items-center justify-center mb-4`}>
                <stat.icon className="w-6 h-6" />
              </div>
              <h3 className="text-3xl font-display font-bold mb-2">{stat.value}</h3>
              <p className="text-muted-foreground font-medium text-sm">{stat.label}</p>
            </motion.div>
          ))}
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <h3 className="text-2xl font-display font-bold">The Failure of Traditional Monitoring</h3>
            <ul className="space-y-4">
              <li className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-red-100 text-red-600 flex items-center justify-center font-bold">1</div>
                <div>
                  <h4 className="font-semibold mb-1">Static Snapshots vs. Temporal Trends</h4>
                  <p className="text-muted-foreground text-sm">Systems like SOFA or NEWS evaluate patients at isolated points in time, missing subtle deterioration patterns developing over hours.</p>
                </div>
              </li>
              <li className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center font-bold">2</div>
                <div>
                  <h4 className="font-semibold mb-1">Alarm Fatigue</h4>
                  <p className="text-muted-foreground text-sm">Simple threshold-based alerts generate too many false positives, causing clinicians to ignore critical warnings.</p>
                </div>
              </li>
              <li className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-bold">3</div>
                <div>
                  <h4 className="font-semibold mb-1">Information Overload</h4>
                  <p className="text-muted-foreground text-sm">ICU patients generate gigabytes of data daily. It is humanly impossible to manually correlate labs, vitals, and demographics simultaneously.</p>
                </div>
              </li>
            </ul>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-slate-50 rounded-3xl p-8 border border-slate-200 relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-[80px]" />
            <h3 className="text-xl font-display font-bold mb-6 relative z-10">The AI Advantage</h3>
            <div className="space-y-6 relative z-10">
              <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100">
                <h4 className="font-semibold text-primary mb-2 flex items-center gap-2">
                  <ActivitySquare className="w-4 h-4" /> Pattern Recognition
                </h4>
                <p className="text-sm text-slate-600">Machine learning models detect complex, non-linear relationships across dozens of variables long before humans can.</p>
              </div>
              <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100">
                <h4 className="font-semibold text-primary mb-2 flex items-center gap-2">
                  <Clock className="w-4 h-4" /> Early Prediction
                </h4>
                <p className="text-sm text-slate-600">Our system predicts sepsis onset up to 6 hours before clinical recognition, providing a crucial window for intervention.</p>
              </div>
            </div>
          </motion.div>
        </div>

      </div>
    </section>
  );
}
