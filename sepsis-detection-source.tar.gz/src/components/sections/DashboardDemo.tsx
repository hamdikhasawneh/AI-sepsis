import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  LineChart, Line, AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, ReferenceLine 
} from 'recharts';
import { Activity, Bell, FileWarning, Search, User, Filter, AlertCircle, Syringe, Clock, Info, TriangleAlert } from 'lucide-react';
import { cn, getRiskColor, getRiskBg } from '@/lib/utils';
import { patients, vitalsHistory, alerts, shapData } from '@/lib/mock-data';

export function DashboardDemo() {
  const [activeTab, setActiveTab] = useState<'doctor' | 'nurse' | 'detail' | 'alerts' | 'shap'>('doctor');
  const [selectedPatient, setSelectedPatient] = useState(patients[2]); // Default ICU-003

  return (
    <section id="dashboard" className="py-24 bg-slate-900 relative overflow-hidden">
      {/* Dark mode background effect */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-primary/20 via-slate-900 to-slate-900" />
      
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-6 text-white">Interactive Platform Demo</h2>
          <p className="text-lg text-slate-400">
            Explore the role-based views. Switch between Doctor and Nurse workflows, analyze alerts, and investigate the AI's reasoning.
          </p>
        </div>

        {/* Browser Mockup Window */}
        <div className="bg-slate-950 rounded-2xl border border-slate-700 shadow-2xl shadow-black overflow-hidden flex flex-col h-[800px]">
          
          {/* Top Bar */}
          <div className="h-14 bg-slate-900 border-b border-slate-800 flex items-center px-4 justify-between shrink-0">
            <div className="flex gap-2">
              <div className="w-3 h-3 rounded-full bg-slate-700" />
              <div className="w-3 h-3 rounded-full bg-slate-700" />
              <div className="w-3 h-3 rounded-full bg-slate-700" />
            </div>
            
            <div className="flex bg-slate-800 rounded-lg p-1">
              {[
                { id: 'doctor', label: 'Doctor View' },
                { id: 'nurse', label: 'Nurse View' },
                { id: 'detail', label: 'Patient Detail' },
                { id: 'alerts', label: 'Alerts (3)' },
                { id: 'shap', label: 'Explainability' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={cn(
                    "px-4 py-1.5 rounded-md text-sm font-medium transition-all duration-200",
                    activeTab === tab.id 
                      ? "bg-slate-700 text-white shadow-sm" 
                      : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50"
                  )}
                >
                  {tab.label}
                </button>
              ))}
            </div>
            
            <div className="flex items-center gap-3 text-slate-400">
              <Bell className="w-5 h-5" />
              <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center border border-slate-700">
                <User className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* Main Content Area */}
          <div className="flex-1 overflow-hidden bg-slate-950 text-slate-300 flex">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="w-full h-full flex"
              >
                {activeTab === 'doctor' && <DoctorView selected={selectedPatient} onSelect={setSelectedPatient} />}
                {activeTab === 'nurse' && <NurseView />}
                {activeTab === 'detail' && <PatientDetailView patient={selectedPatient} />}
                {activeTab === 'alerts' && <AlertsView />}
                {activeTab === 'shap' && <ExplainabilityView patient={selectedPatient} />}
              </motion.div>
            </AnimatePresence>
          </div>

        </div>
      </div>
    </section>
  );
}

// --- Sub-components for Demo Views ---

function DoctorView({ selected, onSelect }: { selected: any, onSelect: (p: any) => void }) {
  return (
    <div className="flex w-full h-full">
      {/* Sidebar List */}
      <div className="w-80 border-r border-slate-800 bg-slate-900/50 flex flex-col shrink-0">
        <div className="p-4 border-b border-slate-800">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input 
              type="text" 
              placeholder="Search patients..." 
              className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-4 py-2 text-sm focus:outline-none focus:border-primary/50 text-slate-200"
            />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {patients.map(p => (
            <div 
              key={p.id}
              onClick={() => onSelect(p)}
              className={cn(
                "p-3 rounded-lg cursor-pointer transition-colors border",
                selected.id === p.id 
                  ? "bg-slate-800 border-slate-700" 
                  : "bg-transparent border-transparent hover:bg-slate-800/50"
              )}
            >
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h4 className="font-semibold text-slate-200">{p.name}</h4>
                  <p className="text-xs text-slate-500">{p.id} • {p.bed}</p>
                </div>
                <div className={cn("px-2 py-0.5 rounded text-xs font-bold", getRiskColor(p.riskLevel as any))}>
                  {p.score}%
                </div>
              </div>
              <div className="flex items-center text-xs text-slate-500">
                <Clock className="w-3 h-3 mr-1" /> Updated {p.lastUpdate}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Main Panel */}
      <div className="flex-1 overflow-y-auto p-6 bg-slate-950">
        <div className="flex justify-between items-start mb-6">
          <div>
            <h2 className="text-2xl font-bold text-white mb-1">{selected.name}</h2>
            <p className="text-slate-400">{selected.id} | {selected.bed} | Age: 62 | Male</p>
          </div>
          
          <div className="flex gap-4">
             <div className="flex flex-col items-end">
              <span className="text-sm text-slate-500 mb-1">Current Sepsis Risk</span>
              <div className="flex items-center gap-3">
                <div className={cn("text-3xl font-bold", selected.riskLevel === 'critical' ? 'text-critical' : 'text-slate-200')}>
                  {selected.score}%
                </div>
                <div className={cn("px-3 py-1 rounded-md text-xs font-bold uppercase tracking-wider", getRiskColor(selected.riskLevel as any))}>
                  {selected.riskLevel}
                </div>
              </div>
             </div>
          </div>
        </div>

        {selected.riskLevel === 'critical' && (
          <div className="mb-6 p-4 rounded-xl bg-critical/10 border border-critical/30 flex items-start gap-4">
            <AlertCircle className="w-6 h-6 text-critical mt-0.5 shrink-0" />
            <div>
              <h4 className="font-bold text-critical">CRITICAL SEPSIS RISK DETECTED</h4>
              <p className="text-sm text-critical/80 mt-1">
                Risk score exceeded 80% threshold. Immediate clinical evaluation recommended. 
                Top contributing factors: Elevated Lactate (3.8), Tachycardia (118).
              </p>
              <div className="mt-3 flex gap-3">
                <button className="px-4 py-2 bg-critical text-white text-sm font-semibold rounded-lg hover:bg-critical/90">Acknowledge</button>
                <button className="px-4 py-2 bg-slate-800 text-slate-200 border border-slate-700 text-sm font-semibold rounded-lg hover:bg-slate-700">Order Protocol</button>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-3 gap-4 mb-6">
          <VitalCard title="Heart Rate" value={selected.hr} unit="bpm" status={selected.hr > 100 ? 'high' : 'normal'} />
          <VitalCard title="Blood Pressure" value={selected.bp} unit="mmHg" status={selected.bp.startsWith('88') ? 'critical' : 'normal'} />
          <VitalCard title="Temperature" value={selected.temp} unit="°C" status={selected.temp > 38 ? 'high' : 'normal'} />
          <VitalCard title="SpO2" value={selected.spo2} unit="%" status={selected.spo2 < 95 ? 'warning' : 'normal'} />
          <VitalCard title="Resp. Rate" value={selected.rr} unit="/min" status={selected.rr > 20 ? 'high' : 'normal'} />
          <VitalCard title="Lactate" value={selected.lactate} unit="mmol/L" status={selected.lactate > 2 ? 'critical' : 'normal'} />
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
          <h4 className="font-semibold text-slate-200 mb-4 flex items-center gap-2"><Activity className="w-4 h-4"/> 24h Risk Trajectory</h4>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={vitalsHistory} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="riskGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--critical))" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="hsl(var(--critical))" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                <XAxis dataKey="time" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} domain={[0, 100]} />
                <RechartsTooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#f8fafc' }}
                  itemStyle={{ color: '#f8fafc' }}
                />
                <ReferenceLine y={80} stroke="hsl(var(--critical))" strokeDasharray="3 3" label={{ value: 'Critical Threshold', fill: 'hsl(var(--critical))', fontSize: 10, position: 'insideTopLeft' }} />
                <Area type="monotone" dataKey="risk" stroke="hsl(var(--critical))" strokeWidth={3} fillOpacity={1} fill="url(#riskGradient)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>
    </div>
  );
}

function VitalCard({ title, value, unit, status }: { title: string, value: string|number, unit: string, status: string }) {
  let color = "text-slate-200";
  if (status === 'high') color = "text-high";
  if (status === 'critical') color = "text-critical";
  if (status === 'warning') color = "text-warning";

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col">
      <span className="text-sm text-slate-500 mb-2">{title}</span>
      <div className="flex items-baseline gap-1">
        <span className={cn("text-2xl font-bold", color)}>{value}</span>
        <span className="text-xs text-slate-500 font-medium">{unit}</span>
      </div>
    </div>
  )
}

function NurseView() {
  return (
    <div className="w-full h-full p-6 overflow-y-auto">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white">Unit Overview</h2>
        <div className="flex gap-2">
          <button className="px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-md text-sm hover:bg-slate-700 flex items-center gap-2">
            <Filter className="w-4 h-4"/> Filter
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="lg:col-span-2 grid grid-cols-2 gap-4">
          {patients.map(p => (
            <div key={p.id} className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col relative overflow-hidden">
              <div className={cn("absolute top-0 left-0 w-1 h-full", getRiskBg(p.riskLevel as any))} />
              <div className="flex justify-between items-start mb-4 pl-2">
                <div>
                  <h4 className="font-semibold text-slate-200">{p.bed}</h4>
                  <p className="text-sm text-slate-400">{p.name}</p>
                </div>
                <div className={cn("px-2 py-1 rounded text-xs font-bold", getRiskColor(p.riskLevel as any))}>
                  Score: {p.score}%
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 text-sm pl-2">
                <div><span className="text-slate-500">HR:</span> <span className={p.hr > 100 ? 'text-high' : ''}>{p.hr}</span></div>
                <div><span className="text-slate-500">BP:</span> {p.bp}</div>
                <div><span className="text-slate-500">RR:</span> {p.rr}</div>
                <div><span className="text-slate-500">SpO2:</span> {p.spo2}%</div>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col">
          <h3 className="font-bold text-slate-200 mb-4 flex items-center gap-2">
            <Syringe className="w-5 h-5 text-primary" /> Enter Lab Results
          </h3>
          <div className="space-y-4 flex-1">
            <div>
              <label className="block text-xs text-slate-500 mb-1">Patient</label>
              <select className="w-full bg-slate-950 border border-slate-700 rounded-md p-2 text-sm text-slate-300">
                {patients.map(p => <option key={p.id}>{p.id} - {p.name}</option>)}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-slate-500 mb-1">Lactate (mmol/L)</label>
                <input type="text" placeholder="e.g. 2.1" className="w-full bg-slate-950 border border-slate-700 rounded-md p-2 text-sm" />
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">WBC (10^9/L)</label>
                <input type="text" placeholder="e.g. 15.2" className="w-full bg-slate-950 border border-slate-700 rounded-md p-2 text-sm" />
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">Creatinine</label>
                <input type="text" placeholder="e.g. 1.2" className="w-full bg-slate-950 border border-slate-700 rounded-md p-2 text-sm" />
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">Platelets</label>
                <input type="text" placeholder="e.g. 150" className="w-full bg-slate-950 border border-slate-700 rounded-md p-2 text-sm" />
              </div>
            </div>
          </div>
          <button className="w-full mt-4 py-2 bg-primary text-primary-foreground rounded-md font-medium hover:bg-primary/90 transition-colors">
            Update Record
          </button>
        </div>
      </div>
    </div>
  );
}

function PatientDetailView({ patient }: { patient: any }) {
  return (
    <div className="w-full h-full p-6 overflow-y-auto">
      <h2 className="text-xl font-bold text-white mb-4 border-b border-slate-800 pb-4">Comprehensive Patient Context</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
          <h3 className="font-semibold text-slate-300 mb-4">Vital Signs Trend (24h)</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={vitalsHistory}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false}/>
                <XAxis dataKey="time" stroke="#64748b" fontSize={12} />
                <YAxis yAxisId="left" stroke="#64748b" fontSize={12} />
                <YAxis yAxisId="right" orientation="right" stroke="#64748b" fontSize={12} />
                <RechartsTooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b' }} />
                <Line yAxisId="left" type="monotone" dataKey="hr" name="Heart Rate" stroke="#ef4444" strokeWidth={2} dot={false} />
                <Line yAxisId="right" type="monotone" dataKey="temp" name="Temperature" stroke="#3b82f6" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
          <h3 className="font-semibold text-slate-300 mb-4">Latest Lab Results</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-slate-500 uppercase bg-slate-950">
                <tr>
                  <th className="px-4 py-2">Test</th>
                  <th className="px-4 py-2">Value</th>
                  <th className="px-4 py-2">Ref Range</th>
                  <th className="px-4 py-2">Time</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-slate-800 bg-critical/5 text-critical">
                  <td className="px-4 py-3 font-medium">Lactate</td>
                  <td className="px-4 py-3 font-bold">3.8 (H)</td>
                  <td className="px-4 py-3 text-slate-500">0.5 - 2.2</td>
                  <td className="px-4 py-3 text-slate-500">10 mins ago</td>
                </tr>
                <tr className="border-b border-slate-800">
                  <td className="px-4 py-3 font-medium text-slate-300">WBC</td>
                  <td className="px-4 py-3 text-high">18.2 (H)</td>
                  <td className="px-4 py-3 text-slate-500">4.5 - 11.0</td>
                  <td className="px-4 py-3 text-slate-500">2 hrs ago</td>
                </tr>
                <tr className="border-b border-slate-800">
                  <td className="px-4 py-3 font-medium text-slate-300">Creatinine</td>
                  <td className="px-4 py-3 text-high">2.1 (H)</td>
                  <td className="px-4 py-3 text-slate-500">0.6 - 1.2</td>
                  <td className="px-4 py-3 text-slate-500">2 hrs ago</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 font-medium text-slate-300">Platelets</td>
                  <td className="px-4 py-3 text-high">89 (L)</td>
                  <td className="px-4 py-3 text-slate-500">150 - 400</td>
                  <td className="px-4 py-3 text-slate-500">2 hrs ago</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
        <h3 className="font-semibold text-slate-300 mb-2 flex items-center gap-2"><FileWarning className="w-4 h-4"/> Clinical Notes Context (MIMIC-IV extract)</h3>
        <p className="text-sm text-slate-400 leading-relaxed font-mono bg-slate-950 p-4 rounded-lg">
          62 yo M presenting from ED with altered mental status, fever, and productive cough. 
          Hypotensive in ED responding poorly to initial 1L crystalloid bolus. Started on empiric broad-spectrum antibiotics (Vanco/Zosyn). 
          Transfer to ICU for closer hemodynamic monitoring. Current concern for developing septic shock secondary to severe community-acquired pneumonia.
        </p>
      </div>
    </div>
  );
}

function AlertsView() {
  return (
    <div className="w-full h-full p-6 overflow-y-auto">
      <div className="flex gap-4 mb-6">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex-1 flex justify-between items-center">
          <div>
            <p className="text-sm text-slate-500">Active Critical</p>
            <p className="text-2xl font-bold text-critical">2</p>
          </div>
          <AlertCircle className="w-8 h-8 text-critical opacity-50" />
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex-1 flex justify-between items-center">
          <div>
            <p className="text-sm text-slate-500">Active High</p>
            <p className="text-2xl font-bold text-high">2</p>
          </div>
          <TriangleAlert className="w-8 h-8 text-high opacity-50" />
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex-1 flex justify-between items-center">
          <div>
            <p className="text-sm text-slate-500">Total Active</p>
            <p className="text-2xl font-bold text-slate-200">8</p>
          </div>
          <Bell className="w-8 h-8 text-slate-500 opacity-50" />
        </div>
      </div>

      <div className="space-y-3">
        {alerts.map(alert => (
          <div key={alert.id} className={cn(
            "p-4 rounded-xl border flex items-start justify-between",
            alert.severity === 'critical' ? 'bg-critical/10 border-critical/30' :
            alert.severity === 'high' ? 'bg-high/10 border-high/30' :
            'bg-slate-900 border-slate-800'
          )}>
            <div className="flex gap-4">
              <div className="mt-1">
                {alert.severity === 'critical' && <AlertCircle className="w-5 h-5 text-critical" />}
                {alert.severity === 'high' && <TriangleAlert className="w-5 h-5 text-high" />}
                {alert.severity === 'medium' && <Info className="w-5 h-5 text-warning" />}
                {alert.severity === 'low' && <Bell className="w-5 h-5 text-slate-500" />}
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-bold text-slate-200">{alert.patientId}</span>
                  <span className="text-xs text-slate-500">{alert.time}</span>
                </div>
                <p className={cn(
                  "text-sm", 
                  alert.severity === 'critical' ? 'text-critical font-medium' : 'text-slate-300'
                )}>{alert.message}</p>
              </div>
            </div>
            {['critical', 'high'].includes(alert.severity) && (
              <button className="shrink-0 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-medium rounded border border-slate-600 transition-colors">
                Review
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function ExplainabilityView({ patient }: { patient: any }) {
  return (
    <div className="w-full h-full p-6 overflow-y-auto flex flex-col">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white mb-2">SHAP Feature Importance</h2>
        <p className="text-slate-400 text-sm">
          Explaining the model's prediction for {patient.name} ({patient.id}). 
          Current risk score: <strong className="text-critical">{patient.score}%</strong>
        </p>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 mb-6">
        <p className="text-sm leading-relaxed text-slate-300">
          <span className="text-primary font-semibold">Natural Language Insight:</span> Elevated lactate levels (3.8 mmol/L), increasing heart rate (118 bpm), falling arterial blood pressure (MAP ~64), and rising respiratory rate (24/min) are the primary positive contributors driving the current high sepsis risk prediction.
        </p>
      </div>

      <div className="flex-1 min-h-[400px] bg-slate-900 border border-slate-800 rounded-xl p-6">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart layout="vertical" data={shapData} margin={{ top: 0, right: 30, left: 60, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" horizontal={true} vertical={false} />
            <XAxis type="number" stroke="#64748b" fontSize={12} domain={[-0.4, 0.4]} />
            <YAxis type="category" dataKey="feature" stroke="#94a3b8" fontSize={12} width={120} tickLine={false} axisLine={false} />
            <RechartsTooltip 
              cursor={{fill: '#1e293b'}}
              contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#f8fafc' }}
              formatter={(value: number) => [value > 0 ? `+${value}` : value, 'Impact on Score']}
            />
            <ReferenceLine x={0} stroke="#475569" strokeWidth={2} />
            <Bar dataKey="impact" radius={[0, 4, 4, 0]}>
              {shapData.map((entry, index) => (
                <cell key={`cell-${index}`} fill={entry.impact > 0 ? "hsl(var(--critical))" : "hsl(var(--primary))"} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
      
      <div className="flex justify-center gap-6 mt-4 text-sm">
        <div className="flex items-center gap-2"><div className="w-3 h-3 bg-critical rounded-sm"/> Push score HIGHER (Risk)</div>
        <div className="flex items-center gap-2"><div className="w-3 h-3 bg-primary rounded-sm"/> Push score LOWER (Safe)</div>
      </div>
    </div>
  );
}
