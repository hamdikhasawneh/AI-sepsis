import { motion } from 'framer-motion';
import { 
  RefreshCw, Brain, Lightbulb, Users, Layers, MonitorSmartphone 
} from 'lucide-react';

const differentiators = [
  {
    icon: RefreshCw,
    title: 'Continuous Prediction, Not Static Thresholds',
    desc: 'Instead of fixed alarm thresholds, the system continuously generates updated risk scores as new data arrives — catching deterioration earlier and reducing alarm fatigue.',
    accent: 'text-blue-600',
    bg: 'bg-blue-50',
    border: 'border-blue-100',
  },
  {
    icon: Brain,
    title: 'Time-Series Aware Modeling',
    desc: 'LSTM and Transformer-based models capture temporal clinical patterns that static models miss, learning how vital signs and labs evolve together over an ICU stay.',
    accent: 'text-violet-600',
    bg: 'bg-violet-50',
    border: 'border-violet-100',
  },
  {
    icon: Lightbulb,
    title: 'SHAP Explainability for Clinician Trust',
    desc: 'Every prediction is accompanied by a ranked list of contributing factors (via SHAP), explaining exactly which vitals and labs drove the risk score — making AI decisions transparent and actionable.',
    accent: 'text-amber-600',
    bg: 'bg-amber-50',
    border: 'border-amber-100',
  },
  {
    icon: Users,
    title: 'Role-Based Clinical Workflow Support',
    desc: 'Separate Doctor and Nurse dashboards adapt to clinical roles: physicians get deep patient analytics, nurses get simplified monitoring and rapid lab upload tools.',
    accent: 'text-teal-600',
    bg: 'bg-teal-50',
    border: 'border-teal-100',
  },
  {
    icon: Layers,
    title: 'Modular Training and Deployment Separation',
    desc: 'The training pipeline (MIMIC-IV preprocessing, model fitting, evaluation) is fully decoupled from the deployment pipeline — enabling iterative model updates without disrupting the running system.',
    accent: 'text-rose-600',
    bg: 'bg-rose-50',
    border: 'border-rose-100',
  },
  {
    icon: MonitorSmartphone,
    title: 'ICU Usability, Not Just Accuracy',
    desc: 'The system is designed with ICU workflow realities in mind: fast alert acknowledgment, minimal data entry friction, and clinically interpretable outputs — not just optimized benchmark metrics.',
    accent: 'text-green-600',
    bg: 'bg-green-50',
    border: 'border-green-100',
  },
];

export function WhyDifferent() {
  return (
    <section id="why-different" className="py-24 bg-slate-50 border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary font-medium text-sm mb-4 border border-primary/20">
            Project Novelty
          </div>
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">
            What Makes This System Different
          </h2>
          <p className="text-lg text-muted-foreground">
            SepsisAI goes beyond model accuracy — it is designed for real ICU deployment, clinical trust, and practical usability.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {differentiators.map((d, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.08 }}
              className={`p-6 rounded-2xl border ${d.border} ${d.bg} hover:shadow-md transition-all group`}
            >
              <div className={`w-12 h-12 rounded-xl bg-white shadow-sm flex items-center justify-center mb-4 ${d.accent}`}>
                <d.icon className="w-6 h-6" />
              </div>
              <h3 className={`text-lg font-bold mb-3 ${d.accent}`}>{d.title}</h3>
              <p className="text-sm text-slate-600 leading-relaxed">{d.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
