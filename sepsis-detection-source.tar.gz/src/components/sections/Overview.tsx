import { motion } from 'framer-motion';
import { Database, Filter, ArrowRight, Brain, AlertTriangle, Monitor } from 'lucide-react';

const pipeline = [
  { icon: Database, label: "ICU Data Sources", desc: "Vitals, Labs, Demographics" },
  { icon: Filter, label: "Preprocessing", desc: "Cleaning & Imputation" },
  { icon: Brain, label: "AI Inference", desc: "LSTM / XGBoost" },
  { icon: AlertTriangle, label: "Risk Engine", desc: "Scoring & Alerting" },
  { icon: Monitor, label: "Dashboard", desc: "UI & Explainability" },
];

export function Overview() {
  return (
    <section id="overview" className="py-24 bg-slate-50 relative border-y border-border/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-primary font-semibold tracking-wider uppercase text-sm mb-4 block">System Overview</span>
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-6">End-to-End AI Clinical Decision Support</h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Our platform continuously ingests real-time ICU streams, processes the data through a validated pipeline, 
            and utilizes advanced deep learning to output actionable insights directly to clinician workflows.
          </p>
        </div>

        <div className="relative mt-20 mb-10">
          {/* Connecting Line */}
          <div className="absolute top-1/2 left-0 w-full h-1 bg-gradient-to-r from-slate-200 via-primary/30 to-slate-200 -translate-y-1/2 hidden md:block" />
          
          <div className="grid grid-cols-1 md:grid-cols-5 gap-6 relative z-10">
            {pipeline.map((step, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.15 }}
                className="flex flex-col items-center group"
              >
                <div className="w-20 h-20 rounded-2xl bg-white border-2 border-slate-100 shadow-xl shadow-slate-200/50 flex items-center justify-center mb-6 group-hover:border-primary/50 group-hover:-translate-y-2 transition-all duration-300 relative">
                  <step.icon className="w-8 h-8 text-slate-700 group-hover:text-primary transition-colors" />
                  
                  {/* Small arrow for mobile */}
                  {idx < pipeline.length - 1 && (
                    <div className="absolute -bottom-8 md:hidden">
                      <ArrowRight className="w-5 h-5 text-slate-300 rotate-90" />
                    </div>
                  )}
                </div>
                <h4 className="font-bold text-foreground text-center mb-1">{step.label}</h4>
                <p className="text-xs text-muted-foreground text-center font-medium">{step.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
}
