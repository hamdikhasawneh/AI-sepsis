import { motion } from 'framer-motion';
import { Network, Database, CheckCircle2 } from 'lucide-react';
import { performanceMetrics } from '@/lib/mock-data';

export function AIModels() {
  return (
    <section id="models" className="py-24 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-6">Model Architecture & Performance</h2>
          <p className="text-lg text-muted-foreground">
            Our system evolved from robust baselines to advanced deep learning architectures designed specifically for irregular clinical time-series data.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 mb-16">
          
          <motion.div initial={{opacity:0, y:20}} whileInView={{opacity:1, y:0}} viewport={{once:true}} className="bg-slate-50 border border-slate-200 rounded-2xl p-8">
            <h3 className="font-display font-bold text-xl mb-4">Baseline Models</h3>
            <ul className="space-y-3 mb-6">
              <li className="flex items-center gap-2 text-sm text-slate-600"><CheckCircle2 className="w-4 h-4 text-slate-400"/> Logistic Regression</li>
              <li className="flex items-center gap-2 text-sm text-slate-600"><CheckCircle2 className="w-4 h-4 text-slate-400"/> Random Forest</li>
              <li className="flex items-center gap-2 text-sm text-slate-600"><CheckCircle2 className="w-4 h-4 text-slate-400"/> Gradient Boosting (LGBM)</li>
            </ul>
            <p className="text-xs text-slate-500 italic">Established strong initial benchmarks using static time-window aggregation.</p>
          </motion.div>

          <motion.div initial={{opacity:0, y:20}} whileInView={{opacity:1, y:0}} viewport={{once:true}} transition={{delay:0.1}} className="bg-primary border border-primary-foreground/10 rounded-2xl p-8 text-white relative overflow-hidden shadow-xl shadow-primary/20">
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-[40px] -mr-10 -mt-10" />
            <h3 className="font-display font-bold text-xl mb-4 relative z-10 text-white">Advanced Time-Series</h3>
            <ul className="space-y-3 mb-6 relative z-10">
              <li className="flex items-center gap-2 text-sm text-blue-100"><Network className="w-4 h-4"/> LSTM Networks</li>
              <li className="flex items-center gap-2 text-sm text-blue-100"><Database className="w-4 h-4"/> XGBoost (Temporal)</li>
              <li className="flex items-center gap-2 text-sm text-blue-100"><Network className="w-4 h-4"/> Transformer-Based Encoders</li>
            </ul>
            <p className="text-xs text-blue-200 italic relative z-10">Captures the trajectory of patient deterioration, yielding superior early-warning capabilities.</p>
          </motion.div>

          <motion.div initial={{opacity:0, y:20}} whileInView={{opacity:1, y:0}} viewport={{once:true}} transition={{delay:0.2}} className="bg-slate-50 border border-slate-200 rounded-2xl p-8">
            <h3 className="font-display font-bold text-xl mb-4">Explainability</h3>
            <ul className="space-y-3 mb-6">
              <li className="flex items-center gap-2 text-sm text-slate-600"><CheckCircle2 className="w-4 h-4 text-slate-400"/> SHAP Values</li>
              <li className="flex items-center gap-2 text-sm text-slate-600"><CheckCircle2 className="w-4 h-4 text-slate-400"/> Feature Importance</li>
              <li className="flex items-center gap-2 text-sm text-slate-600"><CheckCircle2 className="w-4 h-4 text-slate-400"/> Local & Global Explanations</li>
            </ul>
            <p className="text-xs text-slate-500 italic">Ensures clinician trust by preventing the "black box" phenomenon in medical AI.</p>
          </motion.div>

        </div>

        {/* Metrics Bar */}
        <div className="bg-slate-900 rounded-3xl p-8 md:p-10 shadow-2xl">
          <h3 className="text-white font-display font-bold text-2xl mb-8 text-center">Champion Model Performance (LSTM)</h3>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-6 divide-x divide-slate-800">
            {performanceMetrics.map((metric, idx) => (
              <div key={idx} className="flex flex-col items-center px-4">
                <span className="text-4xl font-display font-bold text-primary mb-2">{metric.value}</span>
                <span className="text-sm font-semibold text-white mb-1">{metric.name}</span>
                <span className="text-xs text-slate-400 text-center">{metric.description}</span>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
}
