import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatTime(date: Date | string) {
  const d = new Date(date);
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

export function getRiskColor(level: 'low' | 'medium' | 'high' | 'critical') {
  switch (level) {
    case 'low': return 'text-safe bg-safe/10 border-safe/20';
    case 'medium': return 'text-warning bg-warning/10 border-warning/20';
    case 'high': return 'text-high bg-high/10 border-high/20';
    case 'critical': return 'text-critical bg-critical/10 border-critical/20';
    default: return 'text-muted-foreground bg-muted border-border';
  }
}

export function getRiskBg(level: 'low' | 'medium' | 'high' | 'critical') {
  switch (level) {
    case 'low': return 'bg-safe';
    case 'medium': return 'bg-warning';
    case 'high': return 'bg-high';
    case 'critical': return 'bg-critical';
    default: return 'bg-muted';
  }
}
