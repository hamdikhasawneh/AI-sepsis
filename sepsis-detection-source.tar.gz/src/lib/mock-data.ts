// Mock Data for Dashboard and Charts

export const patients = [
  { id: "ICU-001", name: "Sarah Jenkins",  bed: "Bed 4A", riskLevel: "low",      score: 12, lastUpdate: "2 mins ago",  temp: 36.8, hr: 78,  bp: "120/80", spo2: 98, rr: 14, lactate: 1.2, assignedDoctor: "DOC-001", assignedDoctorName: "Dr. Emily Johnson" },
  { id: "ICU-002", name: "Robert Chen",    bed: "Bed 1B", riskLevel: "medium",   score: 45, lastUpdate: "Just now",    temp: 37.5, hr: 92,  bp: "110/70", spo2: 96, rr: 18, lactate: 1.8, assignedDoctor: "DOC-001", assignedDoctorName: "Dr. Emily Johnson" },
  { id: "ICU-003", name: "James Harrison", bed: "Bed 7C", riskLevel: "critical",  score: 82, lastUpdate: "1 min ago",  temp: 38.9, hr: 118, bp: "88/52",  spo2: 94, rr: 24, lactate: 3.8, assignedDoctor: "DOC-001", assignedDoctorName: "Dr. Emily Johnson", alerts: 3 },
  { id: "ICU-004", name: "Maria Garcia",   bed: "Bed 2A", riskLevel: "low",      score: 18, lastUpdate: "5 mins ago",  temp: 37.0, hr: 82,  bp: "118/76", spo2: 99, rr: 16, lactate: 1.0, assignedDoctor: "DOC-002", assignedDoctorName: "Dr. Alan Torres" },
  { id: "ICU-005", name: "David Smith",    bed: "Bed 5B", riskLevel: "high",     score: 68, lastUpdate: "3 mins ago",  temp: 38.2, hr: 105, bp: "95/60",  spo2: 95, rr: 22, lactate: 2.5, assignedDoctor: "DOC-002", assignedDoctorName: "Dr. Alan Torres", alerts: 1 },
  { id: "ICU-006", name: "Linda Wong",     bed: "Bed 3C", riskLevel: "low",      score: 22, lastUpdate: "10 mins ago", temp: 37.1, hr: 85,  bp: "125/82", spo2: 97, rr: 15, lactate: 1.4, assignedDoctor: "DOC-001", assignedDoctorName: "Dr. Emily Johnson" },
];

export const vitalsHistory = [
  { time: '00:00', hr: 85, rr: 16, temp: 37.2, risk: 34 },
  { time: '04:00', hr: 88, rr: 16, temp: 37.4, risk: 36 },
  { time: '08:00', hr: 92, rr: 18, temp: 37.6, risk: 42 },
  { time: '12:00', hr: 98, rr: 20, temp: 38.0, risk: 55 },
  { time: '16:00', hr: 105, rr: 22, temp: 38.5, risk: 68 },
  { time: '20:00', hr: 112, rr: 23, temp: 38.7, risk: 75 },
  { time: '24:00', hr: 118, rr: 24, temp: 38.9, risk: 82 },
];

export const alerts = [
  { id: 1, patientId: "ICU-003", message: "Sepsis risk score exceeded critical threshold (82%)", time: "2 mins ago",  severity: "critical" },
  { id: 2, patientId: "ICU-003", message: "Lactate level critically high: 3.8 mmol/L",           time: "15 mins ago", severity: "critical" },
  { id: 3, patientId: "ICU-005", message: "Sustained tachycardia > 100 bpm for 2 hours",         time: "45 mins ago", severity: "high" },
  { id: 4, patientId: "ICU-003", message: "Hypotension detected (MAP < 65 mmHg)",                time: "1 hour ago",  severity: "high" },
  { id: 5, patientId: "ICU-002", message: "Risk score trending upward (+15% in 4h)",             time: "2 hours ago", severity: "medium" },
  { id: 6, patientId: "ICU-005", message: "Temperature elevated: 38.2°C",                       time: "3 hours ago", severity: "medium" },
  { id: 7, patientId: "ICU-001", message: "New lab results available",                           time: "4 hours ago", severity: "low" },
  { id: 8, patientId: "ICU-006", message: "Scheduled assessment due",                            time: "5 hours ago", severity: "low" },
];

export const shapData = [
  { feature: "Serum Lactate",    impact:  0.38, direction: "positive" },
  { feature: "Heart Rate (max)", impact:  0.31, direction: "positive" },
  { feature: "MAP",              impact: -0.27, direction: "negative" },
  { feature: "Respiratory Rate", impact:  0.23, direction: "positive" },
  { feature: "WBC Count",        impact:  0.19, direction: "positive" },
  { feature: "Temperature",      impact:  0.14, direction: "positive" },
  { feature: "SpO2 (min)",       impact: -0.12, direction: "negative" },
  { feature: "Creatinine",       impact:  0.10, direction: "positive" },
  { feature: "Platelets",        impact: -0.08, direction: "negative" },
  { feature: "Age",              impact:  0.05, direction: "positive" },
];

export const performanceMetrics = [
  { name: "AUROC",       value: 0.89, description: "Excellent discrimination" },
  { name: "AUPRC",       value: 0.84, description: "Strong precision/recall"  },
  { name: "Sensitivity", value: 0.87, description: "High true positive rate"  },
  { name: "Specificity", value: 0.82, description: "Low false alarm rate"     },
  { name: "F1-Score",    value: 0.85, description: "Balanced performance"     },
];
