import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';

export type UserRole = 'doctor' | 'nurse';

export interface AuthUser {
  name: string;
  role: UserRole;
  department: string;
  email: string;
  id: string;
}

interface AuthContextValue {
  user: AuthUser | null;
  login: (email: string, password: string, role: UserRole) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextValue | null>(null);

const DEMO_CREDENTIALS = {
  doctor: {
    email: 'dr.johnson@hospital.edu',
    password: 'demo1234',
    user: {
      name: 'Dr. Emily Johnson',
      role: 'doctor' as UserRole,
      department: 'Intensive Care Unit',
      email: 'dr.johnson@hospital.edu',
      id: 'DOC-001',
    },
  },
  nurse: {
    email: 'nurse.martinez@hospital.edu',
    password: 'demo1234',
    user: {
      name: 'Sarah Martinez, RN',
      role: 'nurse' as UserRole,
      department: 'ICU Nursing Staff',
      email: 'nurse.martinez@hospital.edu',
      id: 'NRS-001',
    },
  },
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);

  const login = useCallback(async (email: string, password: string, role: UserRole): Promise<{ success: boolean; error?: string }> => {
    await new Promise((r) => setTimeout(r, 800));
    const creds = DEMO_CREDENTIALS[role];
    if (email.trim().toLowerCase() === creds.email && password === creds.password) {
      setUser(creds.user);
      return { success: true };
    }
    if (password === 'demo1234') {
      setUser({ ...creds.user, email, name: role === 'doctor' ? 'Dr. ' + email.split('@')[0] : email.split('@')[0] + ', RN' });
      return { success: true };
    }
    return { success: false, error: 'Invalid credentials. Use password: demo1234' };
  }, []);

  const logout = useCallback(() => setUser(null), []);

  return (
    <AuthContext.Provider value={{ user, login, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}

export { DEMO_CREDENTIALS };
